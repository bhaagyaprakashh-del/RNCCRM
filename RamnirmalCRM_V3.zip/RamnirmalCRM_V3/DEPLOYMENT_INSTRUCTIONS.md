# 🚀 Chit Funds CRM - Complete Deployment Instructions

**Deployment Package Version:** 1.0.0  
**Build ID:** chitfunds2025  
**Target:** app.chitsonline.com  
**Estimated Deployment Time:** 15 minutes

---

## 📋 Pre-Deployment Checklist

Before starting deployment, ensure you have:

- ✅ cPanel access for app.chitsonline.com
- ✅ SSH access (optional, for Python package installation)
- ✅ MySQL database credentials (provided in backend/.env)
- ✅ Cloudflare account access (for cache purging)
- ✅ File manager or FTP client (FileZilla, cPanel File Manager)

---

## 📦 Package Structure

```
deploy/
├── Frontend (upload to: public_html/app.chitsonline.com/)
│   ├── .htaccess
│   ├── index.html
│   ├── login.html
│   ├── dashboard.html
│   ├── favicon.ico
│   ├── robots.txt
│   ├── sitemap.xml
│   └── _next/
│       └── static/
│           ├── css/
│           │   └── app-chitfunds.css
│           ├── chunks/
│           │   └── *.js files
│           └── chitfunds2025/
│               ├── _buildManifest.js
│               └── _ssgManifest.js
│
└── backend/ (upload to: /home/w8fhnbx7quiw/pythonapps/rncrm-api/)
    ├── app.py
    ├── models.py
    ├── passenger_wsgi.py
    ├── requirements.txt
    ├── .env
    └── routes/
        └── *.py files
```

---

## 🔧 Step-by-Step Deployment

### STEP 1: Upload Frontend Files (5 minutes)

**Target Directory:** `public_html/app.chitsonline.com/`

#### Option A: Using cPanel File Manager

1. Log into cPanel
2. Open "File Manager"
3. Navigate to `public_html/app.chitsonline.com/`
4. **IMPORTANT:** Backup existing files if any:
   ```
   - Right-click folder → "Compress" → "Download backup"
   ```
5. Delete old files (if updating existing deployment)
6. Click "Upload" button
7. Upload all files from `deploy/` folder (except `backend/` folder):
   - `.htaccess`
   - `index.html`
   - `login.html`
   - `dashboard.html`
   - `favicon.ico`
   - `robots.txt`
   - `sitemap.xml`
8. Upload the entire `_next/` folder:
   - Click "Upload" → Select the `_next` folder
   - Wait for upload to complete (verify no errors)

#### Option B: Using FTP/SFTP (FileZilla)

```bash
# Connect to your server via FTP
Host: ftp.chitsonline.com
Username: your_cpanel_username
Password: your_cpanel_password
Port: 21 (FTP) or 22 (SFTP)

# Navigate to public_html/app.chitsonline.com/
# Upload all files from deploy/ folder (except backend/)
```

#### Verify Frontend Upload

After upload, verify these files exist:

```bash
# Check via cPanel File Manager or SSH
ls -la public_html/app.chitsonline.com/

Expected files:
- .htaccess
- index.html
- login.html
- dashboard.html
- favicon.ico
- robots.txt
- sitemap.xml
- _next/ (directory)
```

---

### STEP 2: Upload Backend Files (5 minutes)

**Target Directory:** `/home/w8fhnbx7quiw/pythonapps/rncrm-api/`

#### Using cPanel File Manager

1. Navigate to `/home/w8fhnbx7quiw/pythonapps/`
2. Create folder `rncrm-api` if it doesn't exist
3. Enter the `rncrm-api` folder
4. Upload all files from `deploy/backend/`:
   - `app.py`
   - `models.py`
   - `passenger_wsgi.py`
   - `requirements.txt`
   - `.env` (contains your DB credentials)
5. Upload the entire `routes/` folder

#### Verify Backend Upload

```bash
# Check files exist
ls -la /home/w8fhnbx7quiw/pythonapps/rncrm-api/

Expected structure:
- app.py
- models.py
- passenger_wsgi.py
- requirements.txt
- .env
- routes/ (directory with 13 .py files)
```

---

### STEP 3: Configure Python Application in cPanel (3 minutes)

1. **Log into cPanel**
2. **Navigate to:** "Setup Python App" or "Python" section
3. **Click:** "Create Application"
4. **Configure Application:**
   ```
   Python Version: 3.9 or higher (select latest available)
   Application Root: /home/w8fhnbx7quiw/pythonapps/rncrm-api
   Application URL: app.chitsonline.com/api
   Application Startup File: passenger_wsgi.py
   Application Entry Point: application
   ```
5. **Click:** "Create"
6. **Wait** for virtual environment creation (1-2 minutes)

---

### STEP 4: Install Python Dependencies (2 minutes)

#### Option A: Using cPanel Terminal (Recommended)

1. In cPanel, open "Terminal"
2. Run these commands:

```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
source /home/w8fhnbx7quiw/virtualenv/pythonapps/rncrm-api/3.9/bin/activate
pip install -r requirements.txt
```

#### Option B: Using SSH

```bash
ssh your_username@chitsonline.com
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
source venv/bin/activate  # or the path shown in cPanel
pip install -r requirements.txt
```

Expected output:
```
Successfully installed Flask-3.0.0 flask-cors-4.0.0 flask-sqlalchemy-3.1.1 
PyJWT-2.8.0 pymysql-1.1.0 python-dotenv-1.0.0 bcrypt-4.1.2 cryptography-41.0.7
```

---

### STEP 5: Initialize Database (1 minute)

The application will auto-create database tables on first run, but you can manually initialize:

#### Create Tables

```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
source venv/bin/activate
python
```

In Python shell:
```python
from app import create_app
from models import db
app = create_app()
with app.app_context():
    db.create_all()
    print("Database tables created successfully!")
exit()
```

#### Create Admin User

```python
from app import create_app
from models import db, User
app = create_app()
with app.app_context():
    # Check if admin exists
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin',
            email='admin@chitsonline.com',
            first_name='Admin',
            last_name='User',
            role='admin',
            is_active=True
        )
        admin.set_password('Admin@123!')  # Change this password!
        db.session.add(admin)
        db.session.commit()
        print("Admin user created: admin / Admin@123!")
    else:
        print("Admin user already exists")
exit()
```

**⚠️ IMPORTANT:** Change the default password after first login!

---

### STEP 6: Restart Python Application (30 seconds)

After installing dependencies and creating database:

#### Option A: Using cPanel
1. Go to "Setup Python App"
2. Find your application
3. Click "Restart" button

#### Option B: Using Terminal/SSH
```bash
touch /home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger_wsgi.py
```

---

### STEP 7: Verify Deployment (2 minutes)

Run these verification commands from your local machine:

#### 1. Health Checks

```bash
# API health
curl -i https://app.chitsonline.com/api/healthz
# Expected: HTTP/1.1 200 OK
# {"status":"ok","message":"API is running"}

# Database connection
curl -i https://app.chitsonline.com/api/dbz
# Expected: HTTP/1.1 200 OK
# {"status":"ok","message":"Database connection successful"}
```

#### 2. Rewrite Rules

```bash
# Health shortcut
curl -i https://app.chitsonline.com/health
# Should redirect to /api/healthz and return 200

# Session shortcut (should be 401 when not logged in)
curl -i https://app.chitsonline.com/session
# Expected: HTTP/1.1 401 Unauthorized
```

#### 3. Static Assets

```bash
# CSS
curl -I https://app.chitsonline.com/_next/static/css/app-chitfunds.css
# Expected: HTTP/1.1 200 OK, Content-Type: text/css

# Build manifests
curl -I https://app.chitsonline.com/_next/static/chitfunds2025/_buildManifest.js
# Expected: HTTP/1.1 200 OK, Content-Type: application/javascript

curl -I https://app.chitsonline.com/_next/static/chitfunds2025/_ssgManifest.js
# Expected: HTTP/1.1 200 OK
```

#### 4. Login Flow

```bash
# Test login
curl -i -X POST https://app.chitsonline.com/api/auth/login \
  -H 'Content-Type: application/json' \
  --data '{"username":"admin","password":"Admin@123!"}'

# Expected: HTTP/1.1 200 OK
# Look for Set-Cookie headers: rncrm_session=...; authToken=...
# Response body: {"user":{...},"token":"..."}
```

#### 5. Session with Cookies

```bash
# Copy the authToken value from login response, then:
curl -i https://app.chitsonline.com/api/auth/session \
  -H 'Cookie: authToken=<paste_token_here>'

# Expected: HTTP/1.1 200 OK
# {"user":{"id":1,"username":"admin",...}}
```

---

### STEP 8: Purge Cloudflare Cache (1 minute)

1. **Log into Cloudflare dashboard**
2. **Select your domain:** chitsonline.com
3. **Go to:** Caching → Configuration
4. **Click:** "Purge Everything" button
5. **Confirm** the cache purge

**Or purge specific paths:**
- `https://app.chitsonline.com/_next/*`
- `https://app.chitsonline.com/*.html`
- `https://app.chitsonline.com/api/*`

---

### STEP 9: Browser Testing (2 minutes)

1. **Open browser** (Chrome, Firefox, Safari)
2. **Visit:** `https://app.chitsonline.com/`
3. **Expected:** Redirects to `/login.html`
4. **Enter credentials:**
   - Username: `admin`
   - Password: `Admin@123!` (or your password)
5. **Click:** "Sign in"
6. **Expected:** 
   - Success message appears
   - Redirects to `/dashboard.html`
   - Dashboard shows stats and widgets
7. **Test navigation:**
   - Click "Leads" in sidebar
   - Click "Subscribers"
   - Click "Groups"
   - All pages should load without errors
8. **Open DevTools** (F12):
   - Check Console tab: No red errors
   - Check Network tab: All requests return 200 or 304
9. **Test logout:**
   - Click profile icon → Logout
   - Should redirect to login page

---

## ✅ Post-Deployment Validation Checklist

Check off each item after deployment:

### Frontend
- [ ] `index.html` loads and redirects to login
- [ ] `login.html` displays correctly with styled form
- [ ] CSS loads from `/_next/static/css/app-chitfunds.css`
- [ ] No 404 errors in browser console
- [ ] Favicon appears in browser tab

### Backend API
- [ ] `/api/healthz` returns 200 OK
- [ ] `/api/dbz` returns 200 OK (database connected)
- [ ] `/health` rewrite works (redirects to /api/healthz)
- [ ] `/session` rewrite works (returns 401 when logged out)

### Authentication
- [ ] Login form submits to `/api/auth/login`
- [ ] Successful login sets cookies (check in DevTools → Application → Cookies)
- [ ] After login, redirects to `/dashboard.html`
- [ ] Dashboard loads and displays user data
- [ ] Session persists on page refresh
- [ ] Logout clears cookies and redirects to login

### Module Pages (spot check 5-10 pages)
- [ ] Dashboard page loads with stats
- [ ] Leads page loads list from API
- [ ] Subscribers page loads list from API
- [ ] Groups page loads list from API
- [ ] All sidebar menu items work
- [ ] No console errors on any page

### Static Assets
- [ ] All CSS files load (check Network tab)
- [ ] All JavaScript chunks load
- [ ] Build manifests load
- [ ] No missing resources (404s)

### Database
- [ ] Tables created successfully
- [ ] Admin user exists
- [ ] Can create/read/update/delete records
- [ ] Foreign keys work correctly

### Security
- [ ] Cookies have HttpOnly flag
- [ ] Cookies have Secure flag (HTTPS)
- [ ] Cookies have SameSite=Lax
- [ ] JWT tokens expire after 7 days
- [ ] Passwords are hashed (not stored in plain text)

---

## 🐛 Common Issues & Solutions

### Issue 1: "500 Internal Server Error" on API calls

**Symptoms:** API endpoints return 500 errors

**Solutions:**
1. Check Python application logs:
   ```bash
   cat /home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger.log
   tail -f /home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger.log
   ```
2. Verify database connection:
   - Check `.env` file has correct credentials
   - Test MySQL connection manually
3. Restart Python application:
   ```bash
   touch /home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger_wsgi.py
   ```

### Issue 2: "404 Not Found" on static assets

**Symptoms:** CSS or JavaScript files return 404

**Solutions:**
1. Verify files exist:
   ```bash
   ls -la public_html/app.chitsonline.com/_next/static/css/
   ls -la public_html/app.chitsonline.com/_next/static/chunks/
   ```
2. Check file permissions:
   ```bash
   # Directories should be 755
   chmod 755 public_html/app.chitsonline.com/_next
   chmod 755 public_html/app.chitsonline.com/_next/static
   
   # Files should be 644
   find public_html/app.chitsonline.com -type f -exec chmod 644 {} \;
   ```
3. Verify `.htaccess` rules are correct
4. Purge Cloudflare cache

### Issue 3: Login successful but redirects back to login

**Symptoms:** After successful login, immediately redirected to login page

**Solutions:**
1. Check cookies are being set:
   - Open DevTools → Network tab
   - Look at login response headers
   - Should see `Set-Cookie: authToken=...` and `Set-Cookie: rncrm_session=...`
2. Verify cookie attributes:
   - Domain should be `.chitsonline.com` or `app.chitsonline.com`
   - Path should be `/`
   - SameSite should be `Lax` (not `Strict`)
3. Check JavaScript in `login.html`:
   - Verify it's reading cookies correctly
   - Check console for JavaScript errors
4. Clear browser cookies and try again

### Issue 4: CORS errors in browser console

**Symptoms:** Console shows "CORS policy" errors

**Solutions:**
1. Verify CORS configuration in `backend/app.py`:
   ```python
   CORS(app, origins=['https://app.chitsonline.com'], supports_credentials=True)
   ```
2. Ensure frontend requests include credentials:
   ```javascript
   fetch('/api/...', { credentials: 'include' })
   ```
3. Restart Python application after changes

### Issue 5: Database connection fails

**Symptoms:** `/api/dbz` returns error, or database operations fail

**Solutions:**
1. Verify credentials in `.env`:
   ```bash
   cat /home/w8fhnbx7quiw/pythonapps/rncrm-api/.env
   ```
2. Test MySQL connection:
   ```bash
   mysql -h localhost -u appapi -p'Bhaagyaprakashh@55' ChitsonlineCRM
   ```
3. Check if database exists:
   ```sql
   SHOW DATABASES;
   USE ChitsonlineCRM;
   SHOW TABLES;
   ```
4. Verify `@` is encoded as `%40` in connection string

### Issue 6: Pages load but show no data

**Symptoms:** Pages load but lists are empty or show loading forever

**Solutions:**
1. Check API endpoints return data:
   ```bash
   # Test leads API
   curl -i https://app.chitsonline.com/api/leads \
     -H 'Cookie: authToken=<your_token>'
   ```
2. Verify database has records:
   ```sql
   SELECT COUNT(*) FROM leads;
   SELECT COUNT(*) FROM subscribers;
   ```
3. Check browser console for API errors
4. Verify authentication cookies are being sent with requests

---

## 📊 Performance Optimization (Optional)

After successful deployment, consider these optimizations:

### 1. Enable Gzip Compression
Already enabled in `.htaccess`, verify it's working:
```bash
curl -H "Accept-Encoding: gzip" -I https://app.chitsonline.com/_next/static/css/app-chitfunds.css
# Should see: Content-Encoding: gzip
```

### 2. Cloudflare Settings
- **Auto Minify:** Enable for HTML, CSS, JS
- **Brotli:** Enable
- **Rocket Loader:** Enable (test first)
- **Cache Level:** Standard
- **Browser Cache TTL:** 4 hours

### 3. Database Indexing
```sql
-- Add indexes for better query performance
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_subscribers_status ON subscribers(status);
CREATE INDEX idx_collections_date ON collections(collection_date);
CREATE INDEX idx_groups_status ON groups(status);
```

### 4. Python Performance
- Use production WSGI server (Passenger - already configured)
- Enable database connection pooling (already in SQLAlchemy)
- Cache frequently accessed data (consider adding Redis)

---

## 🔐 Security Hardening (Recommended)

### 1. Change Default Passwords
```python
# Change admin password after first login
python
from app import create_app
from models import db, User
app = create_app()
with app.app_context():
    admin = User.query.filter_by(username='admin').first()
    admin.set_password('YourVerySecurePassword123!')
    db.session.commit()
    print("Password changed!")
```

### 2. Update JWT Secret
In `backend/.env`:
```env
JWT_SECRET_KEY=your-very-long-random-secret-key-here
```

### 3. Enable HTTPS (Already enabled via Cloudflare)
- Verify SSL certificate is active
- Force HTTPS redirect in Cloudflare

### 4. Regular Backups
Set up automated backups:
- Database: Daily dumps
- Files: Weekly backups
- Use cPanel backup features

---

## 📞 Support & Maintenance

### Log Files
- **Python logs:** `/home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger.log`
- **Apache logs:** Check cPanel → Errors
- **Application logs:** Check browser DevTools → Console

### Useful Commands
```bash
# View real-time Python logs
tail -f /home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger.log

# Restart Python app
touch /home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger_wsgi.py

# Check disk space
df -h

# Check Python packages
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
source venv/bin/activate
pip list

# Database backup
mysqldump -u appapi -p'Bhaagyaprakashh@55' ChitsonlineCRM > backup_$(date +%Y%m%d).sql
```

### Monitoring
Set up monitoring for:
- Uptime (use UptimeRobot or Pingdom)
- SSL certificate expiration
- Disk space usage
- Database size
- Error rates

---

## 🎉 Deployment Complete!

If all checks pass, your Chit Funds CRM is now live at:

### 🌐 https://app.chitsonline.com/

**What's working:**
- ✅ Complete authentication system
- ✅ All 13 modules with CRUD operations
- ✅ 65+ API endpoints
- ✅ Role-based access control
- ✅ Responsive design
- ✅ Security features enabled

**Next steps:**
1. Change default admin password
2. Create additional user accounts
3. Start entering data (leads, subscribers, groups)
4. Configure email notifications (if needed)
5. Set up automated backups

**Estimated Total Deployment Time:** ~15 minutes

Need help? Review the troubleshooting section or check application logs for detailed error messages.

---

**Deployment Package Information:**
- Version: 1.0.0
- Build ID: chitfunds2025
- Created: October 17, 2025
- Target: app.chitsonline.com
- Technology: Next.js (frontend) + Flask (backend) + MariaDB (database)
