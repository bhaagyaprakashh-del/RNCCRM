# Quick Start Deployment Guide

## Prerequisites
- cPanel access to app.chitsonline.com
- SSH access (optional but recommended)
- Python 3.9+ installed on server
- MySQL/MariaDB database created: ChitsonlineCRM

## 5-Minute Deployment

### Step 1: Upload Files (2 minutes)
```bash
# Using cPanel File Manager or FTP client
# Upload entire /deploy folder contents to:
/home/w8fhnbx7quiw/public_html/app.chitsonline.com/
```

### Step 2: Configure Backend (1 minute)
```bash
# In cPanel > Python App section:
# - Application Root: /home/w8fhnbx7quiw/pythonapps/rncrm-api
# - Application URL: /api
# - Entry Point: passenger_wsgi.py
# - Python Version: 3.9+

# Click "Setup" button
```

### Step 3: Install Dependencies (1 minute)
```bash
# SSH into server
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
pip install -r requirements.txt
```

### Step 4: Initialize Database (30 seconds)
```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
python -c "from app import db; db.create_all()"
```

### Step 5: Restart & Test (30 seconds)
```bash
# Restart Passenger (in cPanel or SSH)
touch /home/w8fhnbx7quiw/pythonapps/rncrm-api/tmp/restart.txt

# Test
curl https://app.chitsonline.com/api/healthz
# Should return: {"status": "healthy"}

# Purge Cloudflare cache (in Cloudflare dashboard)
# Caching > Configuration > Purge Everything
```

## First Login

1. Open: https://app.chitsonline.com/login
2. Default credentials:
   - Username: `admin`
   - Password: `admin123` (change immediately!)
3. After login, you'll be redirected to dashboard

## Quick Validation Tests

```bash
# 1. Static assets
curl -I https://app.chitsonline.com/_next/static/css/app-chitfunds.css

# 2. API health
curl https://app.chitsonline.com/api/healthz

# 3. Database
curl https://app.chitsonline.com/api/dbz

# All should return 200 OK
```

## Troubleshooting

**Problem**: Login page loads but login fails  
**Fix**: Check backend logs, verify database connection

**Problem**: CSS not loading  
**Fix**: Purge Cloudflare cache, check file permissions

**Problem**: API returns 404  
**Fix**: Restart Passenger app, verify Python app mount

## Post-Deployment

- [ ] Change default admin password
- [ ] Create user accounts for team
- [ ] Set up company details in Settings
- [ ] Create branches in Settings > Branches
- [ ] Import or create initial data (leads, subscribers, etc.)
- [ ] Test all major modules
- [ ] Set up regular backups

## Need Help?

See full deployment guide: `DEPLOYMENT_README.md`
