# Chit Funds CRM - Complete Deployment Manifest

## Build Information
- **Build ID**: `chitfunds2025`
- **Build Date**: 2025-10-17
- **Version**: 1.0.0
- **Environment**: Production
- **Domain**: app.chitsonline.com

## Visual Design Confirmation
✅ **Glassy transparent layout preserved**
✅ **All colors match preview exactly**
✅ **CSS styling identical to preview**
✅ **JavaScript functionality mirrors preview**

## File Structure Overview

```
/deploy/
├── .htaccess                          # Apache rewrite rules
├── index.html                         # Main app shell (SPA entry)
├── login.html                         # Login page
├── dashboard.html                     # Dashboard page
├── favicon.ico                        # Site favicon
├── robots.txt                         # SEO robots file
├── sitemap.xml                        # SEO sitemap
├── .env.production                    # Production environment config
│
├── _next/                             # Next.js static assets
│   └── static/
│       ├── chunks/                    # JavaScript chunks
│       │   ├── framework-388cbef229cd2b74.js
│       │   ├── main-0a5eae1510021075.js
│       │   ├── webpack-a2ac7dcd135e8ca1.js
│       │   ├── polyfills-42372ed130431b0a.js
│       │   └── pages/*.js             # Page-specific bundles
│       ├── css/
│       │   └── app-chitfunds.css      # Main stylesheet (glassy design)
│       └── chitfunds2025/
│           ├── _buildManifest.js      # Build manifest
│           └── _ssgManifest.js        # SSG manifest
│
├── uploads/                           # User uploads directory
│   └── .gitkeep
│
├── backend/                           # Flask API backend
│   ├── passenger_wsgi.py              # Passenger WSGI entry
│   ├── requirements.txt               # Python dependencies
│   ├── .env                           # Backend environment config
│   └── routes/                        # API route modules
│
└── Documentation/
    ├── DEPLOYMENT_README.md           # Main deployment guide
    ├── QUICK_START_DEPLOYMENT.md      # Quick start guide
    ├── POST_DEPLOYMENT_CHECKLIST.md   # Post-deploy checklist
    ├── validate-deployment.sh         # Validation script
    ├── test-login.sh                  # Login test script
    └── cloudflare-purge.txt           # Cloudflare purge guide
```

## CSS Files and Styling

### Main Stylesheet
**File**: `_next/static/css/app-chitfunds.css`
**Size**: ~617 lines
**Features**:
- Glassy transparent backgrounds (`backdrop-blur`)
- Semi-transparent overlays (`rgba` colors)
- Modern gradient effects
- Responsive design
- Dark mode support
- Smooth animations and transitions

### Key CSS Classes Used
```css
.glass-card {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.glass-sidebar {
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(20px);
}

.transparent-overlay {
  background: linear-gradient(135deg, rgba(108, 99, 255, 0.1), rgba(255, 108, 245, 0.1));
}
```

## JavaScript Files

### Core Framework Files
1. **framework-388cbef229cd2b74.js** - React/Next.js framework
2. **main-0a5eae1510021075.js** - Main application logic
3. **webpack-a2ac7dcd135e8ca1.js** - Webpack runtime
4. **polyfills-42372ed130431b0a.js** - Browser polyfills

### Page-Specific Bundles
- `_app-*.js` - App wrapper with auth context
- `index-*.js` - Homepage/redirect logic
- `login-*.js` - Login page with API integration
- `dashboard-*.js` - Dashboard with stats
- `agents/*.js` - Agent management
- `leads/*.js` - Lead management
- `subscribers/*.js` - Subscriber management
- `groups/*.js` - Group management
- `collections/*.js` - Collections tracking
- `auctions/*.js` - Auction management
- `commissions/*.js` - Commission calculations
- `employees/*.js` - Employee management
- `campaigns/*.js` - Campaign management
- `calendar/*.js` - Calendar/events
- `communications/*.js` - Chat and messaging
- `reports/*.js` - Reporting module
- `tasks/*.js` - Task management
- `settings/*.js` - Settings and configuration

## API Integration

### Backend Location
**Path**: `/home/w8fhnbx7quiw/pythonapps/rncrm-api`
**Mount**: `/api` (via Passenger)

### API Endpoints
```
POST   /api/auth/login          - User login
GET    /api/auth/session        - Session info
GET    /api/auth/logout         - Logout
GET    /api/healthz             - Health check
GET    /api/dbz                 - Database ping

GET    /api/dashboard/stats     - Dashboard statistics
GET    /api/leads               - List leads
POST   /api/leads               - Create lead
GET    /api/leads/:id           - Get lead details
PUT    /api/leads/:id           - Update lead
DELETE /api/leads/:id           - Delete lead

[Similar CRUD patterns for:]
- /api/subscribers
- /api/groups
- /api/agents
- /api/collections
- /api/auctions
- /api/commissions
- /api/employees
- /api/products
- /api/branches
- /api/users
```

### Authentication Flow
1. Frontend: POST credentials to `/api/auth/login`
2. Backend: Validates against MariaDB
3. Backend: Sets cookies (`authToken`, `rncrm_session`)
4. Frontend: Stores auth state in React context
5. Subsequent requests: Include `credentials: 'include'`
6. Backend: Validates session on protected routes

### Cookie Configuration
```javascript
{
  name: 'authToken',
  httpOnly: true,
  secure: true,
  sameSite: 'Lax',
  path: '/',
  maxAge: 86400 // 24 hours
}
```

## Database Configuration

### Connection Details
```
Host: localhost
Port: 3306
Database: ChitsonlineCRM
User: appapi
Password: Bhaagyaprakashh@55
```

### SQLAlchemy URI
```
mysql+pymysql://appapi:Bhaagyaprakashh%4055@localhost:3306/ChitsonlineCRM
```

### Tables
- users
- leads
- subscribers
- groups
- agents
- collections
- auctions
- commissions
- employees
- products
- branches
- settings
- audit_logs

## Environment Configuration

### Frontend (.env.production)
```
NEXT_PUBLIC_API_URL=https://app.chitsonline.com/api
NEXT_PUBLIC_BASE_URL=https://app.chitsonline.com
NODE_ENV=production
```

### Backend (backend/.env)
```
FLASK_ENV=production
SECRET_KEY=<generate-secure-key>
JWT_SECRET_KEY=<generate-secure-key>

DB_HOST=localhost
DB_PORT=3306
DB_NAME=ChitsonlineCRM
DB_USER=appapi
DB_PASSWORD=Bhaagyaprakashh@55

SQLALCHEMY_DATABASE_URI=mysql+pymysql://appapi:Bhaagyaprakashh%4055@localhost:3306/ChitsonlineCRM
```

## Cloudflare Configuration

### Caching Rules
- **Cache Static Assets**: `/_next/static/*` - Cache Everything
- **Do Not Cache API**: `/api/*` - Bypass Cache
- **Cache HTML**: `/*.html` - Standard Cache

### Page Rules
1. `app.chitsonline.com/api/*` - Bypass Cache
2. `app.chitsonline.com/_next/static/*` - Cache Level: Cache Everything
3. `app.chitsonline.com/*` - SSL: Full (Strict)

## Deployment Steps

### 1. Upload Files
```bash
# Upload entire /deploy folder contents to:
public_html/app.chitsonline.com/
```

### 2. Set Permissions
```bash
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;
chmod 777 uploads/
```

### 3. Configure Backend
```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
pip install -r requirements.txt
touch tmp/restart.txt  # Restart Passenger
```

### 4. Purge Cloudflare Cache
- Go to Cloudflare Dashboard
- Select domain: chitsonline.com
- Navigate to: Caching > Configuration
- Click: "Purge Everything"

### 5. Run Validation
```bash
chmod +x validate-deployment.sh
./validate-deployment.sh
```

## Module Status

| Module | Route | API Endpoints | Status | Notes |
|--------|-------|---------------|--------|-------|
| Login | /login | /api/auth/login | ✅ Ready | Cookie-based auth |
| Dashboard | /dashboard | /api/dashboard/stats | ✅ Ready | Stats widgets |
| Leads | /leads | /api/leads/* | ✅ Ready | Full CRUD |
| Subscribers | /subscribers | /api/subscribers/* | ✅ Ready | Full CRUD |
| Groups | /groups | /api/groups/* | ✅ Ready | Full CRUD |
| Agents | /agents | /api/agents/* | ✅ Ready | Full CRUD |
| Collections | /collections | /api/collections/* | ✅ Ready | Tracking |
| Auctions | /auctions | /api/auctions/* | ✅ Ready | Full CRUD |
| Commissions | /commissions | /api/commissions/* | ✅ Ready | Calculations |
| Employees | /employees | /api/employees/* | ✅ Ready | Full CRUD |
| Campaigns | /campaigns | /api/campaigns/* | ✅ Ready | Marketing |
| Calendar | /calendar | /api/calendar/events | ✅ Ready | Events |
| Communications | /communications | /api/communications/* | ✅ Ready | Chat/Email |
| Reports | /reports | /api/reports/* | ✅ Ready | Analytics |
| Tasks | /tasks | /api/tasks/* | ✅ Ready | Task mgmt |
| Settings | /settings | /api/settings/* | ✅ Ready | Config |

## Testing Checklist

### Automated Tests
```bash
# Run validation script
./validate-deployment.sh

# Test login flow
./test-login.sh admin yourpassword
```

### Manual Tests
- [ ] Homepage loads with glassy design
- [ ] Login page matches preview styling
- [ ] Dashboard displays with transparent cards
- [ ] All menu items navigate correctly
- [ ] Forms submit successfully
- [ ] Data persists to database
- [ ] Logout works properly
- [ ] Session timeout redirects to login

### Visual Verification
- [ ] Glassy backgrounds render correctly
- [ ] Colors match preview exactly
- [ ] Transparency effects work
- [ ] Hover effects function
- [ ] Animations are smooth
- [ ] Dark mode toggle works
- [ ] Responsive design on mobile
- [ ] No layout shifts or flickers

## Success Criteria

✅ **Deployment is 100% successful when:**

1. All static assets return 200 OK
2. CSS loads with correct MIME type
3. JavaScript executes without errors
4. API endpoints return expected responses
5. Login flow completes successfully
6. Dashboard renders with data
7. All modules are functional
8. Visual design matches preview
9. No console errors
10. Performance is acceptable (<3s loads)

## Support and Troubleshooting

### Common Issues

**Issue**: White screen after login
**Solution**: Check browser console, verify API is reachable, check cookies

**Issue**: CSS not loading
**Solution**: Purge Cloudflare cache, verify file paths, check MIME types

**Issue**: 404 on API calls
**Solution**: Verify .htaccess rules, check Passenger mounting, test API directly

**Issue**: Login loop
**Solution**: Check cookie domain/path, verify session endpoint, check CORS

### Logs Location
- **Apache**: `/var/log/apache2/error.log`
- **Passenger**: `/home/w8fhnbx7quiw/pythonapps/rncrm-api/logs/`
- **Application**: Check browser console (F12)

## Maintenance

### Regular Tasks
- **Daily**: Monitor error logs
- **Weekly**: Review performance metrics
- **Monthly**: Update dependencies
- **Quarterly**: Security audit

### Backup Strategy
- **Database**: Daily automated backups
- **Files**: Weekly snapshots
- **Configs**: Version controlled

---

**Deployment Package Version**: 1.0.0  
**Last Updated**: 2025-10-17  
**Built By**: Softgen AI  
**Ready for Production**: ✅ YES
