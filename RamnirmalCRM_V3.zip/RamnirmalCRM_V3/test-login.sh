#!/bin/bash

# Test login flow for Chit Funds CRM
# Usage: ./test-login.sh <username> <password>

BASE_URL="https://app.chitsonline.com"
API_URL="$BASE_URL/api"

USERNAME=$1
PASSWORD=$2

if [ -z "$USERNAME" ] || [ -z "$PASSWORD" ]; then
    echo "Usage: ./test-login.sh <username> <password>"
    echo "Example: ./test-login.sh admin admin123"
    exit 1
fi

echo "=================================="
echo "Testing Login Flow"
echo "=================================="
echo "URL: $API_URL/auth/login"
echo "Username: $USERNAME"
echo ""

# Create temporary cookie file
COOKIE_FILE=$(mktemp)

echo "Step 1: Attempting login..."
LOGIN_RESPONSE=$(curl -s -i -X POST "$API_URL/auth/login" \
    -H "Content-Type: application/json" \
    -c "$COOKIE_FILE" \
    -d "{\"username\":\"$USERNAME\",\"password\":\"$PASSWORD\"}")

HTTP_CODE=$(echo "$LOGIN_RESPONSE" | grep "HTTP/" | tail -1 | awk '{print $2}')

echo "HTTP Status: $HTTP_CODE"
echo ""

if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Login successful!"
    echo ""
    
    # Check for cookies
    echo "Step 2: Checking cookies..."
    if grep -q "authToken" "$COOKIE_FILE"; then
        echo "✓ authToken cookie set"
    else
        echo "✗ authToken cookie NOT set"
    fi
    
    if grep -q "rncrm_session" "$COOKIE_FILE"; then
        echo "✓ rncrm_session cookie set"
    else
        echo "✗ rncrm_session cookie NOT set"
    fi
    echo ""
    
    # Test session endpoint with cookies
    echo "Step 3: Testing session endpoint with cookies..."
    SESSION_RESPONSE=$(curl -s -b "$COOKIE_FILE" "$API_URL/auth/session")
    SESSION_CODE=$(curl -s -o /dev/null -w "%{http_code}" -b "$COOKIE_FILE" "$API_URL/auth/session")
    
    echo "HTTP Status: $SESSION_CODE"
    
    if [ "$SESSION_CODE" = "200" ]; then
        echo "✓ Session verified!"
        echo ""
        echo "User Data:"
        echo "$SESSION_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$SESSION_RESPONSE"
    else
        echo "✗ Session verification failed"
        echo "Response: $SESSION_RESPONSE"
    fi
    
else
    echo "✗ Login failed!"
    echo ""
    echo "Response:"
    echo "$LOGIN_RESPONSE"
fi

# Cleanup
rm -f "$COOKIE_FILE"

echo ""
echo "=================================="
