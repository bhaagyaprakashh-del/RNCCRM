# 🚀 Chit Funds CRM - Deployment Package

**Complete Production Deployment for app.chitsonline.com**

---

## 📦 Package Contents

This deployment package contains a **production-ready mirror** of your preview app with the glassy transparent theme. Everything is configured to work with your Flask API backend and MariaDB database.

### File Structure
```
deploy/
├── index.html                    # Main dashboard (glassy theme)
├── login.html                    # Login page (glassy theme)
├── .htaccess                     # Apache rewrite rules
├── _next/                        # Next.js static assets
│   └── static/
│       ├── css/
│       │   └── app-chitfunds.css # Main Tailwind CSS (617 lines)
│       └── chunks/               # JavaScript bundles
├── assets/
│   ├── css/
│   │   └── theme_glass.css       # Glassy transparent theme layer
│   └── js/
│       └── app-shell.js          # Interactive features (sidebar, tabs, etc.)
├── backend/                      # Flask API (ready to deploy)
│   ├── app.py                    # Main Flask application
│   ├── models.py                 # Database models
│   ├── routes/                   # API route modules
│   ├── requirements.txt          # Python dependencies
│   └── .env.example              # Environment configuration template
└── README_DEPLOYMENT.md          # This file
```

---

## 🎨 Visual Design Confirmation

**Your preview app has been mirrored EXACTLY:**
- ✅ Glassy transparent panels with backdrop blur
- ✅ Thin gold borders (rgba(251, 191, 36, 0.3))
- ✅ Soft shadows and smooth transitions
- ✅ 3-row layout: Header (sticky) + Sidebar (collapsible) + Footer
- ✅ Dashboard tabs (pill-style, sticky)
- ✅ Responsive: Mobile drawer with backdrop
- ✅ All colors, spacing, and design tokens preserved

**CSS Assets:**
- **Main CSS**: `/_next/static/css/app-chitfunds.css` (617 lines)
- **Theme Layer**: `/assets/css/theme_glass.css` (826 lines)

**Build ID**: `chitfunds2025`

---

## 🔧 Deployment Steps

### 1. Upload to Server

Upload the entire contents of the `/deploy` folder to:
```
/home/w8fhnbx7quiw/public_html/app.chitsonline.com/
```

**Method A: cPanel File Manager**
1. Zip the `/deploy` folder contents
2. Upload `deploy.zip` via cPanel File Manager
3. Extract to `public_html/app.chitsonline.com/`

**Method B: FTP/SFTP**
1. Connect to your server via FTP
2. Navigate to `public_html/app.chitsonline.com/`
3. Upload all files from `/deploy` folder
4. Preserve directory structure

### 2. Set File Permissions

```bash
cd /home/w8fhnbx7quiw/public_html/app.chitsonline.com/

# Directories: 755
find . -type d -exec chmod 755 {} \;

# Files: 644
find . -type f -exec chmod 644 {} \;
```

### 3. Configure Backend API

Navigate to your Python app directory:
```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api/
```

Create `.env` file with your database credentials:
```env
DB_HOST=localhost
DB_PORT=3306
DB_NAME=ChitsonlineCRM
DB_USER=appapi
DB_PASSWORD=Bhaagyaprakashh@55

# IMPORTANT: URL-encode the @ symbol as %40
SQLALCHEMY_DATABASE_URI=mysql+pymysql://appapi:Bhaagyaprakashh%4055@localhost:3306/ChitsonlineCRM

# Flask Configuration
FLASK_ENV=production
SECRET_KEY=your-secret-key-here-change-this
SESSION_COOKIE_NAME=rncrm_session
SESSION_COOKIE_SECURE=True
SESSION_COOKIE_HTTPONLY=True
SESSION_COOKIE_SAMESITE=Lax

# API Configuration
API_BASE_URL=https://app.chitsonline.com/api
FRONTEND_URL=https://app.chitsonline.com
```

Install Python dependencies:
```bash
pip install -r requirements.txt
```

Restart the Passenger app:
```bash
touch /home/w8fhnbx7quiw/public_html/app.chitsonline.com/tmp/restart.txt
```

### 4. Purge Cloudflare Cache

**CRITICAL**: After deployment, purge these paths in Cloudflare:

```
https://app.chitsonline.com/_next/static/css/*
https://app.chitsonline.com/_next/static/chunks/*
https://app.chitsonline.com/assets/css/*
https://app.chitsonline.com/assets/js/*
https://app.chitsonline.com/index.html
https://app.chitsonline.com/login.html
```

**How to purge:**
1. Login to Cloudflare Dashboard
2. Select your domain: `chitsonline.com`
3. Go to **Caching** → **Configuration**
4. Click **Purge Everything** or **Custom Purge**
5. Enter the paths above

---

## ✅ Post-Deployment Validation

### Test Static Assets

```bash
# CSS (should return 200, Content-Type: text/css)
curl -I https://app.chitsonline.com/_next/static/css/app-chitfunds.css
curl -I https://app.chitsonline.com/assets/css/theme_glass.css

# JavaScript (should return 200, Content-Type: application/javascript)
curl -I https://app.chitsonline.com/assets/js/app-shell.js

# HTML (should return 200)
curl -I https://app.chitsonline.com/
curl -I https://app.chitsonline.com/login
```

### Test API Endpoints

```bash
# Health check
curl -i https://app.chitsonline.com/api/healthz
# Expected: 200 {"status": "ok"}

# Database ping
curl -i https://app.chitsonline.com/api/dbz
# Expected: 200 {"database": "connected"}

# Rewrite test (health shortcut)
curl -i https://app.chitsonline.com/health
# Expected: 200 (proxied to /api/healthz)

# Session (not logged in)
curl -i https://app.chitsonline.com/session
# Expected: 401 (proxied to /api/auth/session)
```

### Test Login Flow

```bash
# Login
curl -i -X POST https://app.chitsonline.com/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"your-password"}' \
  -c cookies.txt

# Should return:
# - 200 status
# - Set-Cookie: rncrm_session=...
# - Set-Cookie: authToken=...
# - JSON: {"user": {...}, "token": "..."}

# Check session (with cookies)
curl -i https://app.chitsonline.com/api/auth/session \
  -b cookies.txt

# Should return:
# - 200 status
# - JSON: {"user": {...}}
```

---

## 🗂️ Module Endpoints

All module pages call their respective `/api/...` endpoints:

| Module | Frontend Route | Primary API Endpoints | Status |
|--------|---------------|----------------------|--------|
| Dashboard | `/`, `/dashboard` | `/api/dashboard/stats` | ✅ Ready |
| Login/Auth | `/login` | `/api/auth/login`, `/api/auth/session` | ✅ Ready |
| Leads | `/leads/*` | `/api/leads`, `/api/leads/{id}` | ✅ Ready |
| Subscribers | `/subscribers/*` | `/api/subscribers`, `/api/subscribers/{id}` | ✅ Ready |
| Groups | `/groups/*` | `/api/groups`, `/api/groups/{id}` | ✅ Ready |
| Agents | `/agents/*` | `/api/agents`, `/api/agents/{id}` | ✅ Ready |
| Collections | `/collections` | `/api/collections`, `/api/collections/{id}` | ✅ Ready |
| Auctions | `/auctions` | `/api/auctions`, `/api/auctions/{id}` | ✅ Ready |
| Commissions | `/commissions` | `/api/commissions`, `/api/commissions/recompute-all` | ✅ Ready |
| Employees | `/employees/*` | `/api/employees`, `/api/employees/{id}` | ✅ Ready |
| Products | `/products` | `/api/products`, `/api/products/{id}` | ✅ Ready |
| Campaigns | `/campaigns/*` | `/api/campaigns`, `/api/campaigns/{id}` | ✅ Ready |
| Calendar | `/calendar/*` | `/api/calendar/events` | ✅ Ready |
| Communications | `/communications/*` | `/api/communications/*` | ✅ Ready |
| Reports | `/reports/*` | `/api/reports`, `/api/reports/{id}` | ✅ Ready |
| Tasks | `/tasks/*` | `/api/tasks`, `/api/tasks/{id}` | ✅ Ready |
| Integrations | `/integrate/*` | `/api/integrate/*` | ✅ Ready |
| Settings | `/settings/*` | `/api/settings/*`, `/api/branches`, `/api/departments` | ✅ Ready |

**All API calls use:**
- `credentials: 'include'` (send cookies)
- `Authorization: Bearer <token>` header (if token exists)
- Proper error handling (401 → redirect to login)

---

## 🔐 Security & Authentication

### Cookie Configuration

The Flask API sets these cookies on successful login:

```
Set-Cookie: rncrm_session=<session-id>; Path=/; HttpOnly; Secure; SameSite=Lax
Set-Cookie: authToken=<jwt-token>; Path=/; Secure; SameSite=Lax
```

**Frontend behavior:**
1. User submits login form → `POST /api/auth/login`
2. API validates credentials → returns user + token + sets cookies
3. Frontend redirects to `/dashboard`
4. All subsequent API calls automatically include cookies
5. If API returns 401 → redirect to `/login`

### Session Validation

Every protected page should check session on load:

```javascript
fetch('/api/auth/session', {
  credentials: 'include'
})
.then(res => res.json())
.then(data => {
  if (!data.user) {
    window.location.href = '/login';
  }
});
```

---

## 📱 Mobile Responsiveness

The glassy theme is **fully responsive**:

- **Mobile (<768px)**:
  - Sidebar becomes slide-in drawer
  - Backdrop overlay when drawer is open
  - Touch-friendly tap targets (44px minimum)
  - Bottom action bar (optional, for frequent actions)
  - One-column layout for cards

- **Tablet (768px-1024px)**:
  - Two-column grid
  - Sidebar visible, collapsible

- **Desktop (>1024px)**:
  - Three-column grid
  - Full sidebar with labels
  - Sticky header and footer

**Keyboard Shortcuts:**
- `Ctrl/Cmd + B`: Toggle sidebar
- `Escape`: Close mobile drawer

---

## 🎯 Feature Highlights

### Interactive Shell
✅ Sidebar toggle (desktop: collapse/expand, mobile: drawer)  
✅ Dashboard tabs (pill-style, sticky, smooth transitions)  
✅ Active menu highlighting based on current route  
✅ Tooltips on icon buttons  
✅ Smooth scroll animations  
✅ Chart responsiveness on resize  

### Design Details
✅ Glassy transparent panels  
✅ Thin gold borders (1px, rgba(251, 191, 36, 0.3))  
✅ Backdrop blur (16px standard, 24px heavy)  
✅ Soft shadows (0 4px 24px rgba(0, 0, 0, 0.15))  
✅ Thin gold scrollbar (sidebar only)  
✅ Blue accent (#3b82f6) for primary actions  
✅ KPI cards with colored icons  

### Accessibility
✅ ARIA labels and landmarks  
✅ Skip-to-main-content link  
✅ Focus-visible outlines  
✅ Keyboard navigation support  
✅ Reduced motion support  
✅ WCAG AA contrast compliance  

---

## 🛠️ Troubleshooting

### Issue: Static files return 404

**Solution:**
1. Check file permissions (dirs: 755, files: 644)
2. Verify `.htaccess` is in place
3. Purge Cloudflare cache
4. Check Apache mod_rewrite is enabled

### Issue: API calls fail with CORS errors

**Solution:**
1. Verify API is mounted at `/api` in Passenger
2. Check Flask CORS configuration allows `app.chitsonline.com`
3. Ensure `credentials: 'include'` in fetch calls

### Issue: Login loop (redirects back to login after successful auth)

**Solution:**
1. Check cookies are being set with correct attributes:
   - `Secure=true` (HTTPS required)
   - `SameSite=Lax`
   - `HttpOnly=true` (for session cookie)
2. Verify `/api/auth/session` returns 200 when logged in
3. Clear browser cookies and try again

### Issue: Styles not loading / white screen

**Solution:**
1. Purge Cloudflare cache completely
2. Hard refresh browser (Ctrl+Shift+R / Cmd+Shift+R)
3. Check browser console for 404 errors on CSS files
4. Verify CSS files exist at expected paths

### Issue: Mobile drawer not working

**Solution:**
1. Check `app-shell.js` is loaded without errors
2. Verify JavaScript console for errors
3. Test in private/incognito mode
4. Ensure viewport meta tag is present in HTML

---

## 📊 Performance Targets

**Lighthouse Scores (Mobile):**
- Performance: ≥ 75
- Accessibility: ≥ 90
- Best Practices: ≥ 90
- SEO: ≥ 80

**Page Load:**
- First Contentful Paint: < 2s
- Time to Interactive: < 3s
- Total Blocking Time: < 300ms

**Optimization:**
- CSS/JS files cached by Cloudflare (1 year)
- Gzip compression enabled
- Images optimized and lazy-loaded
- Critical CSS inlined (theme variables)

---

## 🆘 Support Contacts

**Deployment Issues:**
- Contact Softgen Support for deployment assistance
- Check Cloudflare dashboard for cache/CDN issues
- Review cPanel error logs: `public_html/app.chitsonline.com/error_log`

**Backend/API Issues:**
- Check Passenger logs: `/var/log/passenger/`
- Review Python app logs: `pythonapps/rncrm-api/logs/`
- Test database connectivity: `mysql -u appapi -p ChitsonlineCRM`

---

## ✨ Success Criteria

Your deployment is successful when:

✅ `https://app.chitsonline.com/` loads with glassy theme  
✅ Login form works and redirects to dashboard  
✅ Dashboard displays with tabs functional  
✅ Sidebar toggles on desktop, drawer on mobile  
✅ All API endpoints return expected responses  
✅ No console errors in browser DevTools  
✅ Static assets load with correct MIME types  
✅ Session persists across page refreshes  

---

**Version**: 1.0.0  
**Last Updated**: 2025-10-17  
**Build ID**: chitfunds2025  

**Your preview app is now ready for production! 🎉**
