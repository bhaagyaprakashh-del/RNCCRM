# Chit Funds CRM - Production Deployment Package

## 🎯 Overview
Complete production-ready deployment package for **app.chitsonline.com**

- **Frontend**: Next.js static build with SSR
- **Backend**: Flask REST API with JWT authentication
- **Database**: MariaDB (ChitsonlineCRM)
- **Platform**: cPanel + Passenger WSGI
- **CDN**: Cloudflare

---

## 📦 Package Contents

```
deploy/
├── .htaccess                          # Apache rewrite rules
├── index.html                         # Main app shell
├── login.html                         # Login page
├── dashboard.html                     # Dashboard page
├── _next/                             # Next.js static assets
│   └── static/
│       ├── chunks/                    # JavaScript bundles
│       │   ├── framework-*.js
│       │   ├── main-*.js
│       │   ├── pages/*.js
│       │   └── webpack-*.js
│       ├── css/                       # Stylesheets
│       │   └── app-*.css
│       └── chitfunds2025/             # Build ID folder
│           ├── _buildManifest.js
│           └── _ssgManifest.js
└── backend/                           # Flask API
    ├── app.py                         # Flask application
    ├── models.py                      # Database models
    ├── passenger_wsgi.py              # WSGI entry point
    ├── requirements.txt               # Python dependencies
    ├── .env                           # Environment config
    └── routes/                        # API endpoints
        ├── __init__.py
        ├── auth.py                    # Authentication
        ├── dashboard.py               # Dashboard stats
        ├── leads.py                   # Lead management
        ├── subscribers.py             # Subscriber management
        ├── groups.py                  # Group management
        ├── agents.py                  # Agent management
        ├── collections.py             # Collection tracking
        ├── auctions.py                # Auction management
        ├── commissions.py             # Commission tracking
        ├── employees.py               # Employee management
        ├── products.py                # Product catalog
        ├── branches.py                # Branch management
        └── users.py                   # User management
```

---

## 🔧 Database Configuration

### Connection Details
```env
DB_HOST=localhost
DB_PORT=3306
DB_NAME=ChitsonlineCRM
DB_USER=appapi
DB_PASSWORD=Bhaagyaprakashh@55

# SQLAlchemy URI (@ encoded as %40)
SQLALCHEMY_DATABASE_URI=mysql+pymysql://appapi:Bhaagyaprakashh%4055@localhost:3306/ChitsonlineCRM
```

### Required Tables
The backend expects these tables in MariaDB:
- `users` - User accounts and authentication
- `branches` - Branch locations
- `leads` - Potential customers
- `subscribers` - Active subscribers
- `groups` - Chit fund groups
- `products` - Product catalog
- `collections` - Payment collections
- `auctions` - Auction records
- `commissions` - Agent commissions
- `employees` - Employee records

---

## 🚀 Deployment Steps

### 1. Upload Files to cPanel

Upload the entire `deploy/` folder contents to:
```
public_html/app.chitsonline.com/
```

**Important**: Upload the *contents* of the deploy folder, not the folder itself.

Final structure should be:
```
public_html/app.chitsonline.com/
├── .htaccess
├── index.html
├── login.html
├── dashboard.html
├── _next/
└── backend/
```

### 2. Configure Python App in cPanel

1. **Navigate to**: cPanel → Setup Python App
2. **Create New Application**:
   - Python Version: `3.9` or higher
   - Application Root: `/home/w8fhnbx7quiw/pythonapps/rncrm-api`
   - Application URL: `app.chitsonline.com/api`
   - Application Startup File: `passenger_wsgi.py`
   - Application Entry Point: `application`

3. **Install Dependencies**:
   ```bash
   cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
   source venv/bin/activate
   pip install -r requirements.txt
   ```

4. **Copy Backend Files**:
   ```bash
   # From your deploy/backend folder to the Python app directory
   cp -r deploy/backend/* /home/w8fhnbx7quiw/pythonapps/rncrm-api/
   ```

5. **Set Environment Variables**:
   - Edit `.env` file in the Python app directory
   - Update `SECRET_KEY` and `JWT_SECRET_KEY` with secure random values

### 3. Verify Database Connection

Test database connectivity:
```bash
curl https://app.chitsonline.com/api/dbz
# Expected: {"status":"ok","message":"Database connection successful"}
```

### 4. Purge Cloudflare Cache

1. Login to Cloudflare dashboard
2. Navigate to Caching → Configuration
3. Click **Purge Everything**
4. Wait 30 seconds for propagation

---

## ✅ Verification Checklist

Run these commands to verify deployment:

### Static Assets
```bash
# Test CSS loading
curl -I https://app.chitsonline.com/_next/static/css/app-chitfunds.css
# Expected: 200 text/css

# Test JavaScript loading
curl -I https://app.chitsonline.com/_next/static/chunks/main-*.js
# Expected: 200 application/javascript

# Test build manifest
curl -I https://app.chitsonline.com/_next/static/chitfunds2025/_buildManifest.js
# Expected: 200 application/javascript
```

### API Endpoints
```bash
# Health check
curl https://app.chitsonline.com/api/healthz
# Expected: {"status":"ok","message":"API is running"}

# Database check
curl https://app.chitsonline.com/api/dbz
# Expected: {"status":"ok","message":"Database connection successful"}

# Session check (should be unauthorized)
curl https://app.chitsonline.com/api/auth/session
# Expected: 401 {"error":"Token is missing"}

# Shortcut health check
curl https://app.chitsonline.com/health
# Expected: 200 (proxied to /api/healthz)
```

### Login Flow
```bash
# Test login endpoint
curl -i -X POST https://app.chitsonline.com/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"your-password"}'

# Expected: 200 with Set-Cookie headers
# Set-Cookie: authToken=...
# Set-Cookie: rncrm_session=...
```

---

## 🔑 API Endpoints Reference

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/session` - Get current session
- `POST /api/auth/register` - Register new user

### Dashboard
- `GET /api/dashboard/stats` - Dashboard statistics
- `GET /api/dashboard/recent-activity` - Recent activity feed

### Leads
- `GET /api/leads` - List leads (paginated)
- `GET /api/leads/:id` - Get lead details
- `POST /api/leads` - Create new lead
- `PUT /api/leads/:id` - Update lead
- `DELETE /api/leads/:id` - Delete lead

### Subscribers
- `GET /api/subscribers` - List subscribers
- `GET /api/subscribers/:id` - Get subscriber details
- `POST /api/subscribers` - Create subscriber
- `PUT /api/subscribers/:id` - Update subscriber
- `DELETE /api/subscribers/:id` - Delete subscriber

### Groups
- `GET /api/groups` - List groups
- `GET /api/groups/:id` - Get group details
- `POST /api/groups` - Create group
- `PUT /api/groups/:id` - Update group
- `DELETE /api/groups/:id` - Delete group

### Agents
- `GET /api/agents` - List agents
- `GET /api/agents/:id` - Get agent details
- `GET /api/agents/:id/performance` - Agent performance metrics

### Collections
- `GET /api/collections` - List collections
- `GET /api/collections/:id` - Get collection details
- `POST /api/collections` - Record collection
- `PUT /api/collections/:id` - Update collection
- `DELETE /api/collections/:id` - Delete collection

### Auctions
- `GET /api/auctions` - List auctions
- `GET /api/auctions/:id` - Get auction details
- `POST /api/auctions` - Create auction
- `PUT /api/auctions/:id` - Update auction
- `DELETE /api/auctions/:id` - Delete auction

### Commissions
- `GET /api/commissions` - List commissions
- `GET /api/commissions/:id` - Get commission details
- `POST /api/commissions` - Create commission
- `PUT /api/commissions/:id` - Update commission
- `DELETE /api/commissions/:id` - Delete commission

### Employees
- `GET /api/employees` - List employees
- `GET /api/employees/:id` - Get employee details
- `POST /api/employees` - Create employee
- `PUT /api/employees/:id` - Update employee
- `DELETE /api/employees/:id` - Delete employee

### Products
- `GET /api/products` - List products
- `GET /api/products/:id` - Get product details
- `POST /api/products` - Create product
- `PUT /api/products/:id` - Update product
- `DELETE /api/products/:id` - Delete product

### Branches
- `GET /api/branches` - List branches
- `GET /api/branches/:id` - Get branch details
- `POST /api/branches` - Create branch
- `PUT /api/branches/:id` - Update branch
- `DELETE /api/branches/:id` - Delete branch

### Users
- `GET /api/users` - List users
- `GET /api/users/:id` - Get user details
- `PUT /api/users/:id` - Update user
- `DELETE /api/users/:id` - Delete user

---

## 🔒 Security Configuration

### Cookies
- `authToken` - JWT authentication token
  - HttpOnly: true
  - Secure: true
  - SameSite: Lax
  - Max-Age: 604800 (7 days)

- `rncrm_session` - Session identifier
  - HttpOnly: true
  - Secure: true
  - SameSite: Lax
  - Max-Age: 604800 (7 days)

### CORS
- Allowed Origins: `https://app.chitsonline.com`
- Credentials: Supported

### JWT
- Algorithm: HS256
- Expiration: 7 days
- Secret: Set in `.env` file

---

## 🐛 Troubleshooting

### Frontend Issues

**Problem**: CSS not loading
```bash
# Check file exists
ls -la public_html/app.chitsonline.com/_next/static/css/

# Check .htaccess MIME types
grep "AddType text/css" public_html/app.chitsonline.com/.htaccess

# Clear Cloudflare cache
```

**Problem**: JavaScript errors
```bash
# Check browser console for 404s
# Verify file paths in index.html match actual files
# Check build manifest exists
```

**Problem**: White screen
```bash
# Check API is responding
curl https://app.chitsonline.com/api/healthz

# Check session endpoint
curl https://app.chitsonline.com/api/auth/session

# Check browser console for errors
```

### Backend Issues

**Problem**: 500 Internal Server Error
```bash
# Check error logs
tail -f /home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger.log

# Verify database connection
curl https://app.chitsonline.com/api/dbz

# Check environment variables
cat /home/w8fhnbx7quiw/pythonapps/rncrm-api/.env
```

**Problem**: Database connection failed
```bash
# Verify credentials
mysql -u appapi -p -h localhost ChitsonlineCRM

# Check SQLAlchemy URI encoding
# @ symbol must be %40 in connection string
```

**Problem**: Module not found
```bash
# Reinstall dependencies
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
source venv/bin/activate
pip install -r requirements.txt

# Restart Python app in cPanel
```

### Authentication Issues

**Problem**: Login returns 401
```bash
# Check user exists in database
mysql -u appapi -p ChitsonlineCRM -e "SELECT * FROM users WHERE username='admin';"

# Verify password hash
# Check JWT_SECRET_KEY is set in .env
```

**Problem**: Session expired immediately
```bash
# Check cookie settings
# Verify domain matches app.chitsonline.com
# Ensure Secure flag works (HTTPS required)
```

---

## 📊 Build Information

**Build ID**: `chitfunds2025`

**Asset Paths**:
- CSS: `/_next/static/css/app-chitfunds.css`
- Main JS: `/_next/static/chunks/main-*.js`
- Framework: `/_next/static/chunks/framework-*.js`
- Build Manifest: `/_next/static/chitfunds2025/_buildManifest.js`
- SSG Manifest: `/_next/static/chitfunds2025/_ssgManifest.js`

**Referenced in**:
- `index.html`
- `login.html`
- `dashboard.html`

---

## 📝 Post-Deployment Tasks

1. **Create Admin User** (if not exists):
   ```python
   # In Python app directory
   from app import create_app
   from models import db, User
   
   app = create_app()
   with app.app_context():
       admin = User(
           username='admin',
           email='admin@chitsonline.com',
           role='admin',
           first_name='Admin',
           last_name='User',
           is_active=True
       )
       admin.set_password('SecurePassword123!')
       db.session.add(admin)
       db.session.commit()
   ```

2. **Set Up Monitoring**:
   - Monitor `/api/healthz` endpoint
   - Set up log rotation for Passenger logs
   - Configure Cloudflare Analytics

3. **Performance Optimization**:
   - Enable Cloudflare caching for static assets
   - Set appropriate cache headers
   - Enable Brotli compression

4. **Backup Configuration**:
   - Schedule database backups
   - Backup `.env` file securely
   - Document any custom configurations

---

## 🎉 Success Indicators

Your deployment is successful when:

✅ `https://app.chitsonline.com` loads the login page
✅ `https://app.chitsonline.com/api/healthz` returns 200
✅ `https://app.chitsonline.com/api/dbz` returns 200
✅ Login functionality works and sets cookies
✅ Dashboard loads after successful login
✅ All API endpoints respond correctly
✅ No console errors in browser
✅ Static assets load with proper MIME types

---

## 📞 Support

For deployment assistance:
- Check logs in cPanel → Python Apps → View Logs
- Review Apache error logs in cPanel
- Verify Cloudflare settings
- Test API endpoints with curl
- Check database connectivity

---

**Deployment Package Version**: 1.0.0  
**Last Updated**: 2025-10-17  
**Platform**: cPanel + Passenger WSGI  
**Database**: MariaDB 10.x  
**Python**: 3.9+  
**Framework**: Flask 3.0.0