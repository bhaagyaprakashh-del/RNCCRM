/**
 * App Shell JavaScript - Glassy Transparent UI
 * Handles sidebar toggle, drawer, and tab navigation
 */

(function() {
  'use strict';

  // ═══════════════════════════════════════════════════════════════
  // 1. SIDEBAR COLLAPSE/EXPAND (DESKTOP)
  // ═══════════════════════════════════════════════════════════════
  
  const initSidebarToggle = () => {
    const hamburgerBtn = document.querySelector('.hamburger-btn');
    const body = document.body;
    
    // Load saved state from localStorage
    const savedState = localStorage.getItem('sbCollapsed');
    if (savedState === 'true') {
      body.classList.add('sidebar-collapsed');
    }
    
    // Toggle sidebar on button click
    if (hamburgerBtn) {
      hamburgerBtn.addEventListener('click', () => {
        const isCollapsed = body.classList.toggle('sidebar-collapsed');
        localStorage.setItem('sbCollapsed', isCollapsed);
        
        // Trigger window resize for chart responsiveness
        setTimeout(() => {
          window.dispatchEvent(new Event('resize'));
        }, 300);
      });
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 2. MOBILE DRAWER
  // ═══════════════════════════════════════════════════════════════
  
  const initMobileDrawer = () => {
    const hamburgerBtn = document.querySelector('.hamburger-btn');
    const body = document.body;
    let backdrop = document.querySelector('.drawer-backdrop');
    
    // Create backdrop if it doesn't exist
    if (!backdrop && window.innerWidth <= 768) {
      backdrop = document.createElement('div');
      backdrop.className = 'drawer-backdrop';
      document.body.appendChild(backdrop);
      
      // Close drawer when backdrop is clicked
      backdrop.addEventListener('click', () => {
        body.classList.remove('drawer-open');
      });
    }
    
    // Toggle drawer on mobile
    if (hamburgerBtn && window.innerWidth <= 768) {
      hamburgerBtn.addEventListener('click', () => {
        body.classList.toggle('drawer-open');
      });
    }
    
    // Close drawer when sidebar links are clicked (mobile)
    const sidebarLinks = document.querySelectorAll('.sidebar-item');
    sidebarLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
          body.classList.remove('drawer-open');
        }
      });
    });
    
    // Handle resize: close drawer and remove backdrop if desktop
    let resizeTimer;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        if (window.innerWidth > 768) {
          body.classList.remove('drawer-open');
          if (backdrop && backdrop.parentNode) {
            backdrop.remove();
          }
        } else if (!backdrop) {
          backdrop = document.createElement('div');
          backdrop.className = 'drawer-backdrop';
          document.body.appendChild(backdrop);
          backdrop.addEventListener('click', () => {
            body.classList.remove('drawer-open');
          });
        }
      }, 250);
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 3. DASHBOARD TABS
  // ═══════════════════════════════════════════════════════════════
  
  const initTabs = () => {
    const tabs = document.querySelectorAll('.tab-item');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const tabId = tab.dataset.tab;
        
        // Remove active class from all tabs and content
        tabs.forEach(t => t.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));
        
        // Add active class to clicked tab and corresponding content
        tab.classList.add('active');
        const targetContent = document.querySelector(`[data-tab-content="${tabId}"]`);
        if (targetContent) {
          targetContent.classList.add('active');
        }
        
        // Trigger window resize for charts
        setTimeout(() => {
          window.dispatchEvent(new Event('resize'));
        }, 100);
      });
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 4. ACTIVE MENU HIGHLIGHTING
  // ═══════════════════════════════════════════════════════════════
  
  const highlightActiveMenu = () => {
    const currentPath = window.location.pathname;
    const menuItems = document.querySelectorAll('.sidebar-item');
    const subItems = document.querySelectorAll('.sidebar-subitem');
    
    // Highlight main items
    menuItems.forEach(item => {
      const href = item.getAttribute('href');
      if (href && (currentPath === href || currentPath.startsWith(href + '/'))) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });
    
    // Highlight sub items and expand parent
    subItems.forEach(item => {
      const href = item.getAttribute('href');
      if (href && currentPath === href) {
        item.classList.add('active');
        // Expand parent group
        const parentGroup = item.closest('.sidebar-group');
        if (parentGroup) {
          parentGroup.classList.add('expanded');
        }
      } else {
        item.classList.remove('active');
      }
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 11. SIDEBAR SUBMENU TOGGLE
  // ═══════════════════════════════════════════════════════════════
  
  const initSubmenuToggle = () => {
    const sidebarGroups = document.querySelectorAll('.sidebar-group');
    
    sidebarGroups.forEach(group => {
      const trigger = group.querySelector('.sidebar-item');
      
      if (trigger) {
        trigger.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          
          // Toggle this group
          const isExpanded = group.classList.contains('expanded');
          
          // Close all other groups (accordion behavior)
          sidebarGroups.forEach(g => {
            if (g !== group) {
              g.classList.remove('expanded');
            }
          });
          
          // Toggle current group
          if (isExpanded) {
            group.classList.remove('expanded');
          } else {
            group.classList.add('expanded');
          }
        });
      }
    });
    
    // Handle subitem clicks (actual navigation)
    const subItems = document.querySelectorAll('.sidebar-subitem');
    subItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        // Let the link navigate normally
      });
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 5. SMOOTH SCROLL FOR ANCHOR LINKS
  // ═══════════════════════════════════════════════════════════════
  
  const initSmoothScroll = () => {
    const anchors = document.querySelectorAll('a[href^="#"]');
    
    anchors.forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href === '#') return;
        
        const target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          target.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      });
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 6. UTILITY: FADE IN ON SCROLL
  // ═══════════════════════════════════════════════════════════════
  
  const initScrollAnimations = () => {
    const elements = document.querySelectorAll('.fade-in, .slide-up');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    });
    
    elements.forEach(el => {
      el.style.opacity = '0';
      if (el.classList.contains('slide-up')) {
        el.style.transform = 'translateY(20px)';
      }
      el.style.transition = 'opacity 0.4s ease-out, transform 0.4s ease-out';
      observer.observe(el);
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 7. CHART RESPONSIVENESS
  // ═══════════════════════════════════════════════════════════════
  
  const initChartResponsiveness = () => {
    let resizeTimer;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        // Trigger chart.js resize if it exists
        if (window.Chart && window.Chart.instances) {
          Object.values(window.Chart.instances).forEach(chart => {
            chart.resize();
          });
        }
      }, 300);
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 8. KEYBOARD SHORTCUTS
  // ═══════════════════════════════════════════════════════════════
  
  const initKeyboardShortcuts = () => {
    document.addEventListener('keydown', (e) => {
      // Ctrl/Cmd + B: Toggle sidebar
      if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
        e.preventDefault();
        const hamburgerBtn = document.querySelector('.hamburger-btn');
        if (hamburgerBtn) {
          hamburgerBtn.click();
        }
      }
      
      // Escape: Close drawer on mobile
      if (e.key === 'Escape') {
        if (document.body.classList.contains('drawer-open')) {
          document.body.classList.remove('drawer-open');
        }
      }
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 9. TOOLTIPS (OPTIONAL)
  // ═══════════════════════════════════════════════════════════════
  
  const initTooltips = () => {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(el => {
      el.addEventListener('mouseenter', function() {
        const text = this.dataset.tooltip;
        const tooltip = document.createElement('div');
        tooltip.className = 'tooltip';
        tooltip.textContent = text;
        tooltip.style.cssText = `
          position: absolute;
          background: var(--glass-bg-heavy);
          backdrop-filter: var(--glass-blur);
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 0.5rem 0.75rem;
          border-radius: 0.5rem;
          font-size: 13px;
          color: var(--text-primary);
          z-index: 1000;
          pointer-events: none;
          white-space: nowrap;
        `;
        
        document.body.appendChild(tooltip);
        
        const rect = this.getBoundingClientRect();
        tooltip.style.top = `${rect.top - tooltip.offsetHeight - 8}px`;
        tooltip.style.left = `${rect.left + (rect.width - tooltip.offsetWidth) / 2}px`;
        
        this._tooltip = tooltip;
      });
      
      el.addEventListener('mouseleave', function() {
        if (this._tooltip) {
          this._tooltip.remove();
          this._tooltip = null;
        }
      });
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 12. HEADER TIME & DATE DISPLAY (LIVE UPDATE)
  // ═══════════════════════════════════════════════════════════════
  
  const initHeaderTime = () => {
    const timeElement = document.getElementById('currentDateTime');
    
    if (timeElement) {
      const updateTime = () => {
        const now = new Date();
        const options = {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          hour12: true
        };
        
        // Format: "Sat, 18 Oct, 2025, 01:58 am"
        timeElement.textContent = now.toLocaleDateString('en-IN', options);
      };
      
      // Update immediately
      updateTime();
      
      // Update every minute
      setInterval(updateTime, 60000);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 13. NOTIFICATION DROPDOWN
  // ═══════════════════════════════════════════════════════════════
  
  const initNotifications = () => {
    const notificationBtn = document.getElementById('notificationBtn');
    const notificationPanel = document.getElementById('notificationPanel');
    const markAllReadBtn = document.getElementById('markAllRead');
    const notificationBadge = document.getElementById('notificationBadge');
    
    if (!notificationBtn || !notificationPanel) return;
    
    // Toggle notification panel
    notificationBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isVisible = notificationPanel.style.display === 'block';
      
      // Close user menu if open
      const userMenuPanel = document.getElementById('userMenuPanel');
      if (userMenuPanel) {
        userMenuPanel.style.display = 'none';
      }
      
      notificationPanel.style.display = isVisible ? 'none' : 'block';
    });
    
    // Mark all as read
    if (markAllReadBtn) {
      markAllReadBtn.addEventListener('click', () => {
        const notificationItems = document.querySelectorAll('.notification-item');
        notificationItems.forEach(item => {
          item.classList.remove('unread');
        });
        
        // Update badge
        if (notificationBadge) {
          notificationBadge.textContent = '0';
          notificationBadge.style.display = 'none';
        }
      });
    }
    
    // Mark individual notification as read
    const notificationItems = document.querySelectorAll('.notification-item');
    notificationItems.forEach(item => {
      item.addEventListener('click', () => {
        item.classList.remove('unread');
        
        // Update badge count
        const unreadCount = document.querySelectorAll('.notification-item.unread').length;
        if (notificationBadge) {
          notificationBadge.textContent = unreadCount.toString();
          if (unreadCount === 0) {
            notificationBadge.style.display = 'none';
          }
        }
      });
    });
    
    // Close when clicking outside
    document.addEventListener('click', (e) => {
      if (!notificationBtn.contains(e.target) && !notificationPanel.contains(e.target)) {
        notificationPanel.style.display = 'none';
      }
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 14. USER PROFILE DROPDOWN
  // ═══════════════════════════════════════════════════════════════
  
  const initUserProfile = () => {
    const userProfileBtn = document.getElementById('userProfileBtn');
    const userMenuPanel = document.getElementById('userMenuPanel');
    const notificationMenuBtn = document.getElementById('notificationMenuBtn');
    
    if (!userProfileBtn || !userMenuPanel) return;
    
    // Toggle user menu panel
    userProfileBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isVisible = userMenuPanel.style.display === 'block';
      
      // Close notification panel if open
      const notificationPanel = document.getElementById('notificationPanel');
      if (notificationPanel) {
        notificationPanel.style.display = 'none';
      }
      
      userMenuPanel.style.display = isVisible ? 'none' : 'block';
    });
    
    // Handle notification button in user menu
    if (notificationMenuBtn) {
      notificationMenuBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        // Close user menu
        userMenuPanel.style.display = 'none';
        
        // Open notification panel
        const notificationPanel = document.getElementById('notificationPanel');
        if (notificationPanel) {
          notificationPanel.style.display = 'block';
        }
      });
    }
    
    // Close when clicking outside
    document.addEventListener('click', (e) => {
      if (!userProfileBtn.contains(e.target) && !userMenuPanel.contains(e.target)) {
        userMenuPanel.style.display = 'none';
      }
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 15. HEADER SEARCH FUNCTIONALITY
  // ═══════════════════════════════════════════════════════════════
  
  const initHeaderSearch = () => {
    const searchForm = document.getElementById('headerSearchForm');
    const searchInput = document.getElementById('headerSearchInput');
    const searchBtn = document.querySelector('.header-search-btn');
    
    if (!searchForm || !searchInput) return;
    
    // Show search form on desktop
    if (window.innerWidth > 768) {
      searchForm.style.display = 'block';
    }
    
    // Toggle search on mobile when button clicked
    if (searchBtn) {
      searchBtn.addEventListener('click', () => {
        const isVisible = searchForm.style.display === 'block';
        searchForm.style.display = isVisible ? 'none' : 'block';
        if (!isVisible) {
          searchInput.focus();
        }
      });
    }
    
    // Handle form submission
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleSearch(searchInput.value.trim());
    });
    
    // Keyboard shortcut: Ctrl+K or Cmd+K
    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        searchInput.focus();
        searchInput.select();
      }
    });
    
    // Handle window resize
    window.addEventListener('resize', () => {
      if (window.innerWidth > 768) {
        searchForm.style.display = 'block';
      } else if (!searchInput.value) {
        searchForm.style.display = 'none';
      }
    });
  };
  
  const handleSearch = (query) => {
    if (!query) return;
    
    const searchLower = query.toLowerCase();
    
    // Define all searchable routes
    const allRoutes = [
      // Main modules
      { name: 'Dashboard', path: '/dashboard', keywords: ['home', 'overview', 'stats'] },
      { name: 'Leads', path: '/leads', keywords: ['sales', 'customers', 'prospects'] },
      { name: 'Tasks', path: '/tasks', keywords: ['tickets', 'todo', 'assignments'] },
      { name: 'Campaigns', path: '/campaigns', keywords: ['marketing', 'email', 'sms'] },
      { name: 'Communications', path: '/communications', keywords: ['email', 'chat', 'messages'] },
      { name: 'Calendar', path: '/calendar', keywords: ['schedule', 'events', 'meetings'] },
      { name: 'Subscribers', path: '/subscribers', keywords: ['members', 'customers'] },
      { name: 'Agents', path: '/agents', keywords: ['representatives', 'staff'] },
      { name: 'Groups', path: '/groups', keywords: ['chit', 'branches'] },
      { name: 'Collections', path: '/collections', keywords: ['payments', 'money'] },
      { name: 'Auctions', path: '/auctions', keywords: ['bidding', 'bids'] },
      { name: 'Commissions', path: '/commissions', keywords: ['payouts', 'earnings'] },
      { name: 'Employees', path: '/employees', keywords: ['hrms', 'staff', 'payroll'] },
      { name: 'Products', path: '/products', keywords: ['catalog', 'services'] },
      { name: 'Reports', path: '/reports', keywords: ['analytics', 'charts'] },
      { name: 'Settings', path: '/settings', keywords: ['configuration', 'admin'] },
      { name: 'Integrate', path: '/integrate', keywords: ['sync', 'api', 'integrations'] },
      { name: 'Customize', path: '/customize', keywords: ['theme', 'appearance'] },
      
      // Child pages
      { name: 'Kanban View', path: '/leads/kanban', keywords: ['board', 'pipeline'] },
      { name: 'New Lead', path: '/leads/new', keywords: ['create', 'add'] },
      { name: 'Lead 360', path: '/leads/360', keywords: ['details', 'profile'] },
      { name: 'Task Board', path: '/tasks/board', keywords: ['kanban', 'status'] },
      { name: 'Tickets', path: '/tasks/tickets', keywords: ['support', 'help'] },
      { name: 'Broadcast', path: '/campaigns/broadcast', keywords: ['bulk', 'send'] },
      { name: 'Templates', path: '/campaigns/templates', keywords: ['email templates'] },
      { name: 'Live Chat', path: '/communications/chat', keywords: ['messaging'] },
      { name: 'Compose Email', path: '/communications/compose', keywords: ['write', 'send'] },
      { name: 'My Events', path: '/calendar/my-events', keywords: ['personal', 'schedule'] },
      { name: 'Team Calendar', path: '/calendar/team', keywords: ['shared', 'group'] },
      { name: 'New Subscriber', path: '/subscribers/new', keywords: ['create', 'add'] },
      { name: 'Agent Targets', path: '/agents/targets', keywords: ['goals', 'rankings'] },
      { name: 'Daily Diary', path: '/agents/diary', keywords: ['log', 'notes'] },
      { name: 'Group Overview', path: '/groups/overview', keywords: ['branches', 'summary'] },
      { name: 'Create Group', path: '/groups/create', keywords: ['new', 'allocate'] },
      { name: 'Attendance', path: '/employees/attendance', keywords: ['time', 'logs'] },
      { name: 'Payroll', path: '/employees/payroll', keywords: ['salary', 'payslips'] },
      { name: 'Employee KPI', path: '/employees/kpi', keywords: ['performance', 'metrics'] },
      { name: 'My Reports', path: '/reports/my-reports', keywords: ['saved', 'personal'] },
      { name: 'Scheduled Reports', path: '/reports/scheduled', keywords: ['automated', 'recurring'] },
      { name: 'Data Sync', path: '/integrate/sync', keywords: ['import', 'export'] },
      { name: 'Field Mappings', path: '/integrate/mappings', keywords: ['columns', 'mapping'] },
      { name: 'Theme Settings', path: '/customize/theme', keywords: ['colors', 'appearance'] },
      { name: 'Company Profile', path: '/settings/company', keywords: ['organization', 'branding'] },
      { name: 'Branches', path: '/settings/branches', keywords: ['locations', 'offices'] },
      { name: 'Users', path: '/users', keywords: ['accounts', 'permissions'] },
      { name: 'Roles', path: '/settings/roles', keywords: ['permissions', 'access'] },
    ];
    
    // Find matching routes
    const matches = allRoutes.filter(route => {
      return route.name.toLowerCase().includes(searchLower) ||
             route.keywords.some(keyword => keyword.includes(searchLower));
    });
    
    if (matches.length > 0) {
      // Navigate to first match
      window.location.href = matches[0].path;
      
      // Clear search input
      const searchInput = document.getElementById('headerSearchInput');
      if (searchInput) {
        searchInput.value = '';
        searchInput.blur();
      }
    } else {
      // Show "no results" message (could be a toast notification)
      console.log('No matching pages found for:', query);
      alert(`No results found for "${query}"`);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 16. SIDEBAR MODULE SEARCH
  // ═══════════════════════════════════════════════════════════════
  
  const initSidebarSearch = () => {
    const sidebarSearch = document.getElementById('sidebarSearchInput');
    
    if (!sidebarSearch) return;
    
    sidebarSearch.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase().trim();
      const sidebarGroups = document.querySelectorAll('.sidebar-group');
      const singleItems = document.querySelectorAll('.sidebar-item:not(.sidebar-group .sidebar-item)');
      
      // Filter groups and their items
      sidebarGroups.forEach(group => {
        const parentItem = group.querySelector('.sidebar-item');
        const subItems = group.querySelectorAll('.sidebar-subitem');
        const parentText = parentItem ? parentItem.textContent.toLowerCase() : '';
        
        let groupMatches = parentText.includes(query);
        let anySubItemMatches = false;
        
        // Check sub-items
        subItems.forEach(subItem => {
          const subText = subItem.textContent.toLowerCase();
          const matches = subText.includes(query);
          
          if (matches) {
            anySubItemMatches = true;
            subItem.style.display = 'block';
          } else {
            subItem.style.display = query ? 'none' : 'block';
          }
        });
        
        // Show group if parent or any child matches
        if (groupMatches || anySubItemMatches || !query) {
          group.style.display = 'block';
          // Auto-expand if search is active and has matches
          if (query && anySubItemMatches) {
            group.classList.add('expanded');
          }
        } else {
          group.style.display = 'none';
        }
      });
      
      // Filter single items (without children)
      singleItems.forEach(item => {
        const itemText = item.textContent.toLowerCase();
        const matches = itemText.includes(query);
        
        if (matches || !query) {
          item.style.display = 'flex';
        } else {
          item.style.display = 'none';
        }
      });
      
      // If no query, reset all
      if (!query) {
        sidebarGroups.forEach(group => {
          group.style.display = 'block';
          group.classList.remove('expanded');
          const subItems = group.querySelectorAll('.sidebar-subitem');
          subItems.forEach(sub => {
            sub.style.display = 'block';
          });
        });
      }
    });
    
    // Keyboard shortcut: Cmd+K or Ctrl+K focuses sidebar search too
    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        
        // If header search is visible, focus it; otherwise focus sidebar search
        const headerSearch = document.getElementById('headerSearchInput');
        if (headerSearch && window.getComputedStyle(headerSearch.parentElement).display !== 'none') {
          headerSearch.focus();
          headerSearch.select();
        } else {
          sidebarSearch.focus();
          sidebarSearch.select();
        }
      }
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 17. AVATAR UPLOAD FUNCTIONALITY
  // ═══════════════════════════════════════════════════════════════
  
  const initAvatarUpload = () => {
    const avatarInput = document.getElementById('avatarUploadInput');
    
    if (!avatarInput) return;
    
    avatarInput.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      
      if (!file) return;
      
      // Validate file type
      if (!file.type.startsWith('image/')) {
        alert('Please select a valid image file');
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('Image size must be less than 5MB');
        return;
      }
      
      // Show loading state
      const avatars = document.querySelectorAll('.user-avatar');
      avatars.forEach(avatar => {
        avatar.style.opacity = '0.5';
      });
      
      try {
        // Create FormData
        const formData = new FormData();
        formData.append('avatar', file);
        
        // Upload to API
        const response = await fetch('/api/users/upload-avatar', {
          method: 'POST',
          credentials: 'include',
          body: formData
        });
        
        if (!response.ok) {
          throw new Error('Upload failed');
        }
        
        const data = await response.json();
        
        // Update avatar display with uploaded image
        if (data.avatarUrl) {
          avatars.forEach(avatar => {
            avatar.style.backgroundImage = `url(${data.avatarUrl})`;
            avatar.style.backgroundSize = 'cover';
            avatar.style.backgroundPosition = 'center';
            avatar.textContent = '';
            avatar.style.opacity = '1';
          });
          
          // Store in localStorage for persistence
          localStorage.setItem('userAvatar', data.avatarUrl);
          
          // Show success message
          alert('Avatar updated successfully!');
        }
      } catch (error) {
        console.error('Avatar upload error:', error);
        alert('Failed to upload avatar. Please try again.');
        
        // Restore opacity
        avatars.forEach(avatar => {
          avatar.style.opacity = '1';
        });
      }
      
      // Clear input
      e.target.value = '';
      
      // Close user menu
      const userMenuPanel = document.getElementById('userMenuPanel');
      if (userMenuPanel) {
        userMenuPanel.style.display = 'none';
      }
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 10. INITIALIZE ALL
  // ═══════════════════════════════════════════════════════════════
  
  const init = () => {
    // Check for reduced motion preference
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (!prefersReducedMotion) {
      initScrollAnimations();
    }
    
    initSidebarToggle();
    initMobileDrawer();
    initTabs();
    highlightActiveMenu();
    initSmoothScroll();
    initChartResponsiveness();
    initKeyboardShortcuts();
    initTooltips();
    initSubmenuToggle();
    initHeaderTime();
    initNotifications();
    initUserProfile();
    initHeaderSearch();
    initSidebarSearch();
    initAvatarUpload();
    
    // Log initialization
    console.log('✨ Glassy UI Shell initialized');
  };

  // ═══════════════════════════════════════════════════════════════
  // DOM READY
  // ═══════════════════════════════════════════════════════════════
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
