from flask import Blueprint, request, jsonify
from models import db, Subscriber
from routes.auth import token_required
from datetime import datetime
import random
import string

subscribers_bp = Blueprint('subscribers', __name__)

def generate_customer_id():
    return 'CUST' + ''.join(random.choices(string.digits, k=8))

@subscribers_bp.route('', methods=['GET'])
@token_required
def get_subscribers(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = Subscriber.query
    
    # Filter by role
    if current_user.role == 'agent':
        query = query.filter_by(agent_id=current_user.id)
    elif current_user.role != 'admin':
        query = query.filter_by(branch_id=current_user.branch_id)
    
    pagination = query.order_by(Subscriber.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'subscribers': [sub.to_dict() for sub in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@subscribers_bp.route('/<int:subscriber_id>', methods=['GET'])
@token_required
def get_subscriber(current_user, subscriber_id):
    subscriber = Subscriber.query.get_or_404(subscriber_id)
    
    # Check permissions
    if current_user.role == 'agent' and subscriber.agent_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    return jsonify(subscriber.to_dict()), 200

@subscribers_bp.route('', methods=['POST'])
@token_required
def create_subscriber(current_user):
    data = request.get_json()
    
    if not data.get('name') or not data.get('phone'):
        return jsonify({'error': 'Name and phone are required'}), 400
    
    subscriber = Subscriber(
        customer_id=generate_customer_id(),
        name=data['name'],
        email=data.get('email'),
        phone=data['phone'],
        alternate_phone=data.get('alternatePhone'),
        address=data.get('address'),
        city=data.get('city'),
        state=data.get('state'),
        pincode=data.get('pincode'),
        branch_id=data.get('branchId', current_user.branch_id),
        agent_id=data.get('agentId', current_user.id),
        kyc_status=data.get('kycStatus', 'pending')
    )
    
    db.session.add(subscriber)
    db.session.commit()
    
    return jsonify(subscriber.to_dict()), 201

@subscribers_bp.route('/<int:subscriber_id>', methods=['PUT'])
@token_required
def update_subscriber(current_user, subscriber_id):
    subscriber = Subscriber.query.get_or_404(subscriber_id)
    
    # Check permissions
    if current_user.role == 'agent' and subscriber.agent_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    if 'name' in data:
        subscriber.name = data['name']
    if 'email' in data:
        subscriber.email = data['email']
    if 'phone' in data:
        subscriber.phone = data['phone']
    if 'alternatePhone' in data:
        subscriber.alternate_phone = data['alternatePhone']
    if 'address' in data:
        subscriber.address = data['address']
    if 'city' in data:
        subscriber.city = data['city']
    if 'state' in data:
        subscriber.state = data['state']
    if 'pincode' in data:
        subscriber.pincode = data['pincode']
    if 'kycStatus' in data:
        subscriber.kyc_status = data['kycStatus']
    if 'isActive' in data:
        subscriber.is_active = data['isActive']
    
    subscriber.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify(subscriber.to_dict()), 200

@subscribers_bp.route('/<int:subscriber_id>', methods=['DELETE'])
@token_required
def delete_subscriber(current_user, subscriber_id):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    subscriber = Subscriber.query.get_or_404(subscriber_id)
    db.session.delete(subscriber)
    db.session.commit()
    
    return jsonify({'message': 'Subscriber deleted successfully'}), 200
