from flask import Blueprint, request, jsonify
from models import db, Employee, User
from routes.auth import token_required
from datetime import datetime

employees_bp = Blueprint('employees', __name__)

@employees_bp.route('', methods=['GET'])
@token_required
def get_employees(current_user):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    pagination = Employee.query.order_by(Employee.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    employees_data = []
    for employee in pagination.items:
        emp_dict = employee.to_dict()
        
        # Add user info
        if employee.user_id:
            user = User.query.get(employee.user_id)
            if user:
                emp_dict['user'] = user.to_dict()
        
        employees_data.append(emp_dict)
    
    return jsonify({
        'employees': employees_data,
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@employees_bp.route('/<int:employee_id>', methods=['GET'])
@token_required
def get_employee(current_user, employee_id):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    employee = Employee.query.get_or_404(employee_id)
    emp_dict = employee.to_dict()
    
    # Add user info
    if employee.user_id:
        user = User.query.get(employee.user_id)
        if user:
            emp_dict['user'] = user.to_dict()
    
    return jsonify(emp_dict), 200

@employees_bp.route('', methods=['POST'])
@token_required
def create_employee(current_user):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    required_fields = ['employeeId', 'userId', 'designation']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Check if employee already exists for this user
    existing = Employee.query.filter_by(user_id=data['userId']).first()
    if existing:
        return jsonify({'error': 'Employee record already exists for this user'}), 409
    
    employee = Employee(
        user_id=data['userId'],
        employee_id=data['employeeId'],
        designation=data['designation'],
        department=data.get('department'),
        joining_date=datetime.fromisoformat(data['joiningDate']) if data.get('joiningDate') else None,
        salary=data.get('salary'),
        is_active=data.get('isActive', True)
    )
    
    db.session.add(employee)
    db.session.commit()
    
    return jsonify(employee.to_dict()), 201

@employees_bp.route('/<int:employee_id>', methods=['PUT'])
@token_required
def update_employee(current_user, employee_id):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    employee = Employee.query.get_or_404(employee_id)
    data = request.get_json()
    
    if 'designation' in data:
        employee.designation = data['designation']
    if 'department' in data:
        employee.department = data['department']
    if 'joiningDate' in data:
        employee.joining_date = datetime.fromisoformat(data['joiningDate']) if data['joiningDate'] else None
    if 'salary' in data:
        employee.salary = data['salary']
    if 'isActive' in data:
        employee.is_active = data['isActive']
    
    db.session.commit()
    
    return jsonify(employee.to_dict()), 200

@employees_bp.route('/<int:employee_id>', methods=['DELETE'])
@token_required
def delete_employee(current_user, employee_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    employee = Employee.query.get_or_404(employee_id)
    db.session.delete(employee)
    db.session.commit()
    
    return jsonify({'message': 'Employee deleted successfully'}), 200
