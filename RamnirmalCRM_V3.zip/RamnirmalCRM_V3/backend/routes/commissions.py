from flask import Blueprint, request, jsonify
from models import db, Commission
from routes.auth import token_required
from datetime import datetime

commissions_bp = Blueprint('commissions', __name__)

@commissions_bp.route('', methods=['GET'])
@token_required
def get_commissions(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    agent_id = request.args.get('agent_id', type=int)
    
    query = Commission.query
    
    # Filter by role
    if current_user.role == 'agent':
        query = query.filter_by(agent_id=current_user.id)
    elif agent_id:
        query = query.filter_by(agent_id=agent_id)
    
    # Filter by status
    if status:
        query = query.filter_by(status=status)
    
    pagination = query.order_by(Commission.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'commissions': [commission.to_dict() for commission in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@commissions_bp.route('/<int:commission_id>', methods=['GET'])
@token_required
def get_commission(current_user, commission_id):
    commission = Commission.query.get_or_404(commission_id)
    
    # Check permissions
    if current_user.role == 'agent' and commission.agent_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    return jsonify(commission.to_dict()), 200

@commissions_bp.route('', methods=['POST'])
@token_required
def create_commission(current_user):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    required_fields = ['agentId', 'type', 'amount']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    commission = Commission(
        agent_id=data['agentId'],
        type=data['type'],
        reference_id=data.get('referenceId'),
        amount=data['amount'],
        rate=data.get('rate'),
        status=data.get('status', 'pending'),
        payment_date=datetime.fromisoformat(data['paymentDate']) if data.get('paymentDate') else None,
        notes=data.get('notes')
    )
    
    db.session.add(commission)
    db.session.commit()
    
    return jsonify(commission.to_dict()), 201

@commissions_bp.route('/<int:commission_id>', methods=['PUT'])
@token_required
def update_commission(current_user, commission_id):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    commission = Commission.query.get_or_404(commission_id)
    data = request.get_json()
    
    if 'status' in data:
        commission.status = data['status']
    if 'paymentDate' in data:
        commission.payment_date = datetime.fromisoformat(data['paymentDate']) if data['paymentDate'] else None
    if 'notes' in data:
        commission.notes = data['notes']
    
    db.session.commit()
    
    return jsonify(commission.to_dict()), 200

@commissions_bp.route('/<int:commission_id>', methods=['DELETE'])
@token_required
def delete_commission(current_user, commission_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    commission = Commission.query.get_or_404(commission_id)
    db.session.delete(commission)
    db.session.commit()
    
    return jsonify({'message': 'Commission deleted successfully'}), 200
