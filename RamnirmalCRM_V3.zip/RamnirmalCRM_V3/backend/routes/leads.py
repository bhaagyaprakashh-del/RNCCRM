from flask import Blueprint, request, jsonify
from models import db, Lead
from routes.auth import token_required
from datetime import datetime

leads_bp = Blueprint('leads', __name__)

@leads_bp.route('', methods=['GET'])
@token_required
def get_leads(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    
    query = Lead.query
    
    # Filter by role
    if current_user.role == 'agent':
        query = query.filter_by(assigned_to=current_user.id)
    elif current_user.role != 'admin':
        query = query.filter_by(branch_id=current_user.branch_id)
    
    # Filter by status
    if status:
        query = query.filter_by(status=status)
    
    pagination = query.order_by(Lead.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'leads': [lead.to_dict() for lead in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@leads_bp.route('/<int:lead_id>', methods=['GET'])
@token_required
def get_lead(current_user, lead_id):
    lead = Lead.query.get_or_404(lead_id)
    
    # Check permissions
    if current_user.role == 'agent' and lead.assigned_to != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    return jsonify(lead.to_dict()), 200

@leads_bp.route('', methods=['POST'])
@token_required
def create_lead(current_user):
    data = request.get_json()
    
    if not data.get('name') or not data.get('phone'):
        return jsonify({'error': 'Name and phone are required'}), 400
    
    lead = Lead(
        name=data['name'],
        email=data.get('email'),
        phone=data['phone'],
        alternate_phone=data.get('alternatePhone'),
        address=data.get('address'),
        city=data.get('city'),
        state=data.get('state'),
        pincode=data.get('pincode'),
        source=data.get('source'),
        status=data.get('status', 'new'),
        assigned_to=data.get('assignedTo', current_user.id),
        branch_id=data.get('branchId', current_user.branch_id),
        interest_level=data.get('interestLevel'),
        notes=data.get('notes')
    )
    
    db.session.add(lead)
    db.session.commit()
    
    return jsonify(lead.to_dict()), 201

@leads_bp.route('/<int:lead_id>', methods=['PUT'])
@token_required
def update_lead(current_user, lead_id):
    lead = Lead.query.get_or_404(lead_id)
    
    # Check permissions
    if current_user.role == 'agent' and lead.assigned_to != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    if 'name' in data:
        lead.name = data['name']
    if 'email' in data:
        lead.email = data['email']
    if 'phone' in data:
        lead.phone = data['phone']
    if 'alternatePhone' in data:
        lead.alternate_phone = data['alternatePhone']
    if 'address' in data:
        lead.address = data['address']
    if 'city' in data:
        lead.city = data['city']
    if 'state' in data:
        lead.state = data['state']
    if 'pincode' in data:
        lead.pincode = data['pincode']
    if 'source' in data:
        lead.source = data['source']
    if 'status' in data:
        lead.status = data['status']
    if 'assignedTo' in data:
        lead.assigned_to = data['assignedTo']
    if 'interestLevel' in data:
        lead.interest_level = data['interestLevel']
    if 'notes' in data:
        lead.notes = data['notes']
    
    lead.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify(lead.to_dict()), 200

@leads_bp.route('/<int:lead_id>', methods=['DELETE'])
@token_required
def delete_lead(current_user, lead_id):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    lead = Lead.query.get_or_404(lead_id)
    db.session.delete(lead)
    db.session.commit()
    
    return jsonify({'message': 'Lead deleted successfully'}), 200
