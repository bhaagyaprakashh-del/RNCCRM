from flask import Blueprint, request, jsonify
from models import db, User, Lead, Subscriber, Commission
from routes.auth import token_required
from sqlalchemy import func

agents_bp = Blueprint('agents', __name__)

@agents_bp.route('', methods=['GET'])
@token_required
def get_agents(current_user):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = User.query.filter_by(role='agent')
    
    # Filter by branch if not admin
    if current_user.role != 'admin':
        query = query.filter_by(branch_id=current_user.branch_id)
    
    pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    agents_data = []
    for agent in pagination.items:
        agent_dict = agent.to_dict()
        
        # Add performance metrics
        agent_dict['totalLeads'] = Lead.query.filter_by(assigned_to=agent.id).count()
        agent_dict['totalSubscribers'] = Subscriber.query.filter_by(agent_id=agent.id).count()
        
        # Commission stats
        total_commission = db.session.query(func.sum(Commission.amount)).filter(
            Commission.agent_id == agent.id,
            Commission.status == 'paid'
        ).scalar() or 0
        agent_dict['totalCommission'] = float(total_commission)
        
        pending_commission = db.session.query(func.sum(Commission.amount)).filter(
            Commission.agent_id == agent.id,
            Commission.status == 'pending'
        ).scalar() or 0
        agent_dict['pendingCommission'] = float(pending_commission)
        
        agents_data.append(agent_dict)
    
    return jsonify({
        'agents': agents_data,
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@agents_bp.route('/<int:agent_id>', methods=['GET'])
@token_required
def get_agent(current_user, agent_id):
    if current_user.role not in ['admin', 'manager'] and current_user.id != agent_id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    agent = User.query.get_or_404(agent_id)
    
    if agent.role != 'agent':
        return jsonify({'error': 'User is not an agent'}), 400
    
    agent_dict = agent.to_dict()
    
    # Add performance metrics
    agent_dict['totalLeads'] = Lead.query.filter_by(assigned_to=agent.id).count()
    agent_dict['totalSubscribers'] = Subscriber.query.filter_by(agent_id=agent.id).count()
    
    return jsonify(agent_dict), 200

@agents_bp.route('/<int:agent_id>/performance', methods=['GET'])
@token_required
def get_agent_performance(current_user, agent_id):
    if current_user.role not in ['admin', 'manager'] and current_user.id != agent_id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    agent = User.query.get_or_404(agent_id)
    
    performance = {
        'totalLeads': Lead.query.filter_by(assigned_to=agent.id).count(),
        'convertedLeads': Lead.query.filter_by(assigned_to=agent.id, status='converted').count(),
        'totalSubscribers': Subscriber.query.filter_by(agent_id=agent.id).count(),
        'activeSubscribers': Subscriber.query.filter_by(agent_id=agent.id, is_active=True).count()
    }
    
    # Commission stats
    total_commission = db.session.query(func.sum(Commission.amount)).filter(
        Commission.agent_id == agent.id,
        Commission.status == 'paid'
    ).scalar() or 0
    performance['totalCommission'] = float(total_commission)
    
    pending_commission = db.session.query(func.sum(Commission.amount)).filter(
        Commission.agent_id == agent.id,
        Commission.status == 'pending'
    ).scalar() or 0
    performance['pendingCommission'] = float(pending_commission)
    
    return jsonify(performance), 200
