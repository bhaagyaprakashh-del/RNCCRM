from flask import Blueprint, request, jsonify
from models import db, Collection
from routes.auth import token_required
from datetime import datetime

collections_bp = Blueprint('collections', __name__)

@collections_bp.route('', methods=['GET'])
@token_required
def get_collections(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    
    query = Collection.query
    
    # Filter by role
    if current_user.role == 'agent':
        query = query.filter_by(collected_by=current_user.id)
    
    # Filter by status
    if status:
        query = query.filter_by(status=status)
    
    pagination = query.order_by(Collection.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'collections': [collection.to_dict() for collection in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@collections_bp.route('/<int:collection_id>', methods=['GET'])
@token_required
def get_collection(current_user, collection_id):
    collection = Collection.query.get_or_404(collection_id)
    return jsonify(collection.to_dict()), 200

@collections_bp.route('', methods=['POST'])
@token_required
def create_collection(current_user):
    data = request.get_json()
    
    required_fields = ['subscriberId', 'groupId', 'installmentNumber', 'amount', 'paymentDate']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    collection = Collection(
        subscriber_id=data['subscriberId'],
        group_id=data['groupId'],
        installment_number=data['installmentNumber'],
        amount=data['amount'],
        payment_date=datetime.fromisoformat(data['paymentDate']) if data.get('paymentDate') else datetime.utcnow(),
        payment_mode=data.get('paymentMode'),
        transaction_id=data.get('transactionId'),
        collected_by=data.get('collectedBy', current_user.id),
        status=data.get('status', 'paid'),
        notes=data.get('notes')
    )
    
    db.session.add(collection)
    db.session.commit()
    
    return jsonify(collection.to_dict()), 201

@collections_bp.route('/<int:collection_id>', methods=['PUT'])
@token_required
def update_collection(current_user, collection_id):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    collection = Collection.query.get_or_404(collection_id)
    data = request.get_json()
    
    if 'status' in data:
        collection.status = data['status']
    if 'paymentMode' in data:
        collection.payment_mode = data['paymentMode']
    if 'transactionId' in data:
        collection.transaction_id = data['transactionId']
    if 'notes' in data:
        collection.notes = data['notes']
    
    db.session.commit()
    
    return jsonify(collection.to_dict()), 200

@collections_bp.route('/<int:collection_id>', methods=['DELETE'])
@token_required
def delete_collection(current_user, collection_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    collection = Collection.query.get_or_404(collection_id)
    db.session.delete(collection)
    db.session.commit()
    
    return jsonify({'message': 'Collection deleted successfully'}), 200
