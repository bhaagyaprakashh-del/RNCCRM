from flask import Blueprint, request, jsonify
from models import db, Branch
from routes.auth import token_required

branches_bp = Blueprint('branches', __name__)

@branches_bp.route('', methods=['GET'])
@token_required
def get_branches(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = Branch.query.filter_by(is_active=True)
    
    pagination = query.order_by(Branch.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'branches': [branch.to_dict() for branch in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@branches_bp.route('/<int:branch_id>', methods=['GET'])
@token_required
def get_branch(current_user, branch_id):
    branch = Branch.query.get_or_404(branch_id)
    return jsonify(branch.to_dict()), 200

@branches_bp.route('', methods=['POST'])
@token_required
def create_branch(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    required_fields = ['name', 'code']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Check if code already exists
    existing = Branch.query.filter_by(code=data['code']).first()
    if existing:
        return jsonify({'error': 'Branch code already exists'}), 409
    
    branch = Branch(
        name=data['name'],
        code=data['code'],
        address=data.get('address'),
        city=data.get('city'),
        state=data.get('state'),
        pincode=data.get('pincode'),
        phone=data.get('phone'),
        email=data.get('email'),
        manager_id=data.get('managerId'),
        is_active=data.get('isActive', True)
    )
    
    db.session.add(branch)
    db.session.commit()
    
    return jsonify(branch.to_dict()), 201

@branches_bp.route('/<int:branch_id>', methods=['PUT'])
@token_required
def update_branch(current_user, branch_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    branch = Branch.query.get_or_404(branch_id)
    data = request.get_json()
    
    if 'name' in data:
        branch.name = data['name']
    if 'address' in data:
        branch.address = data['address']
    if 'city' in data:
        branch.city = data['city']
    if 'state' in data:
        branch.state = data['state']
    if 'pincode' in data:
        branch.pincode = data['pincode']
    if 'phone' in data:
        branch.phone = data['phone']
    if 'email' in data:
        branch.email = data['email']
    if 'managerId' in data:
        branch.manager_id = data['managerId']
    if 'isActive' in data:
        branch.is_active = data['isActive']
    
    db.session.commit()
    
    return jsonify(branch.to_dict()), 200

@branches_bp.route('/<int:branch_id>', methods=['DELETE'])
@token_required
def delete_branch(current_user, branch_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    branch = Branch.query.get_or_404(branch_id)
    db.session.delete(branch)
    db.session.commit()
    
    return jsonify({'message': 'Branch deleted successfully'}), 200
