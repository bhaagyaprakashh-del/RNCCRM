from flask import Blueprint, request, jsonify
from models import db, Product
from routes.auth import token_required

products_bp = Blueprint('products', __name__)

@products_bp.route('', methods=['GET'])
@token_required
def get_products(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = Product.query.filter_by(is_active=True)
    
    pagination = query.order_by(Product.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'products': [product.to_dict() for product in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@products_bp.route('/<int:product_id>', methods=['GET'])
@token_required
def get_product(current_user, product_id):
    product = Product.query.get_or_404(product_id)
    return jsonify(product.to_dict()), 200

@products_bp.route('', methods=['POST'])
@token_required
def create_product(current_user):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    required_fields = ['name', 'code', 'chitValue', 'durationMonths', 'maxMembers']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Check if code already exists
    existing = Product.query.filter_by(code=data['code']).first()
    if existing:
        return jsonify({'error': 'Product code already exists'}), 409
    
    product = Product(
        name=data['name'],
        code=data['code'],
        description=data.get('description'),
        chit_value=data['chitValue'],
        duration_months=data['durationMonths'],
        max_members=data['maxMembers'],
        commission_percentage=data.get('commissionPercentage'),
        is_active=data.get('isActive', True)
    )
    
    db.session.add(product)
    db.session.commit()
    
    return jsonify(product.to_dict()), 201

@products_bp.route('/<int:product_id>', methods=['PUT'])
@token_required
def update_product(current_user, product_id):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    product = Product.query.get_or_404(product_id)
    data = request.get_json()
    
    if 'name' in data:
        product.name = data['name']
    if 'description' in data:
        product.description = data['description']
    if 'chitValue' in data:
        product.chit_value = data['chitValue']
    if 'durationMonths' in data:
        product.duration_months = data['durationMonths']
    if 'maxMembers' in data:
        product.max_members = data['maxMembers']
    if 'commissionPercentage' in data:
        product.commission_percentage = data['commissionPercentage']
    if 'isActive' in data:
        product.is_active = data['isActive']
    
    db.session.commit()
    
    return jsonify(product.to_dict()), 200

@products_bp.route('/<int:product_id>', methods=['DELETE'])
@token_required
def delete_product(current_user, product_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    
    return jsonify({'message': 'Product deleted successfully'}), 200
