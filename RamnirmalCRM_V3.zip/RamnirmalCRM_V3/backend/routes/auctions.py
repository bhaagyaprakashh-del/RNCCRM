from flask import Blueprint, request, jsonify
from models import db, Auction
from routes.auth import token_required
from datetime import datetime

auctions_bp = Blueprint('auctions', __name__)

@auctions_bp.route('', methods=['GET'])
@token_required
def get_auctions(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    group_id = request.args.get('group_id', type=int)
    status = request.args.get('status')
    
    query = Auction.query
    
    # Filter by group
    if group_id:
        query = query.filter_by(group_id=group_id)
    
    # Filter by status
    if status:
        query = query.filter_by(status=status)
    
    pagination = query.order_by(Auction.auction_date.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'auctions': [auction.to_dict() for auction in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@auctions_bp.route('/<int:auction_id>', methods=['GET'])
@token_required
def get_auction(current_user, auction_id):
    auction = Auction.query.get_or_404(auction_id)
    return jsonify(auction.to_dict()), 200

@auctions_bp.route('', methods=['POST'])
@token_required
def create_auction(current_user):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    required_fields = ['groupId', 'auctionNumber', 'auctionDate']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    auction = Auction(
        group_id=data['groupId'],
        auction_number=data['auctionNumber'],
        auction_date=datetime.fromisoformat(data['auctionDate']) if data.get('auctionDate') else datetime.utcnow(),
        winner_id=data.get('winnerId'),
        bid_amount=data.get('bidAmount'),
        prize_amount=data.get('prizeAmount'),
        dividend_amount=data.get('dividendAmount'),
        status=data.get('status', 'scheduled')
    )
    
    db.session.add(auction)
    db.session.commit()
    
    return jsonify(auction.to_dict()), 201

@auctions_bp.route('/<int:auction_id>', methods=['PUT'])
@token_required
def update_auction(current_user, auction_id):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    auction = Auction.query.get_or_404(auction_id)
    data = request.get_json()
    
    if 'winnerId' in data:
        auction.winner_id = data['winnerId']
    if 'bidAmount' in data:
        auction.bid_amount = data['bidAmount']
    if 'prizeAmount' in data:
        auction.prize_amount = data['prizeAmount']
    if 'dividendAmount' in data:
        auction.dividend_amount = data['dividendAmount']
    if 'status' in data:
        auction.status = data['status']
    
    db.session.commit()
    
    return jsonify(auction.to_dict()), 200

@auctions_bp.route('/<int:auction_id>', methods=['DELETE'])
@token_required
def delete_auction(current_user, auction_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    auction = Auction.query.get_or_404(auction_id)
    db.session.delete(auction)
    db.session.commit()
    
    return jsonify({'message': 'Auction deleted successfully'}), 200
