from flask import Blueprint, jsonify
from models import db, User, Lead, Subscriber, Group, Collection, Auction
from routes.auth import token_required
from sqlalchemy import func
from datetime import datetime, timedelta

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/stats', methods=['GET'])
@token_required
def get_stats(current_user):
    # Get stats based on user role
    stats = {}
    
    if current_user.role == 'admin':
        # Admin sees everything
        stats['totalLeads'] = Lead.query.count()
        stats['totalSubscribers'] = Subscriber.query.count()
        stats['totalGroups'] = Group.query.count()
        stats['activeGroups'] = Group.query.filter_by(status='active').count()
        stats['totalAgents'] = User.query.filter_by(role='agent').count()
        
        # Collection stats
        total_collected = db.session.query(func.sum(Collection.amount)).filter(
            Collection.status == 'paid'
        ).scalar() or 0
        stats['totalCollected'] = float(total_collected)
        
        # This month's collection
        first_day = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        month_collected = db.session.query(func.sum(Collection.amount)).filter(
            Collection.status == 'paid',
            Collection.payment_date >= first_day
        ).scalar() or 0
        stats['monthlyCollection'] = float(month_collected)
        
        # Recent auctions
        stats['recentAuctions'] = Auction.query.order_by(Auction.auction_date.desc()).limit(5).count()
        
    elif current_user.role == 'agent':
        # Agent sees their own stats
        stats['myLeads'] = Lead.query.filter_by(assigned_to=current_user.id).count()
        stats['mySubscribers'] = Subscriber.query.filter_by(agent_id=current_user.id).count()
        stats['myCollections'] = Collection.query.filter_by(collected_by=current_user.id).count()
        
        # Agent's commission
        from models import Commission
        pending_commission = db.session.query(func.sum(Commission.amount)).filter(
            Commission.agent_id == current_user.id,
            Commission.status == 'pending'
        ).scalar() or 0
        stats['pendingCommission'] = float(pending_commission)
        
    elif current_user.role == 'employee':
        # Employee sees limited stats
        stats['totalSubscribers'] = Subscriber.query.count()
        stats['totalGroups'] = Group.query.count()
        stats['activeGroups'] = Group.query.filter_by(status='active').count()
        
    return jsonify(stats), 200

@dashboard_bp.route('/recent-activity', methods=['GET'])
@token_required
def get_recent_activity(current_user):
    activities = []
    
    # Get recent leads
    recent_leads = Lead.query.order_by(Lead.created_at.desc()).limit(5).all()
    for lead in recent_leads:
        activities.append({
            'type': 'lead',
            'message': f'New lead: {lead.name}',
            'timestamp': lead.created_at.isoformat() if lead.created_at else None
        })
    
    # Get recent collections
    recent_collections = Collection.query.order_by(Collection.created_at.desc()).limit(5).all()
    for collection in recent_collections:
        activities.append({
            'type': 'collection',
            'message': f'Payment collected: ₹{float(collection.amount)}',
            'timestamp': collection.created_at.isoformat() if collection.created_at else None
        })
    
    # Sort by timestamp
    activities.sort(key=lambda x: x['timestamp'], reverse=True)
    
    return jsonify(activities[:10]), 200
