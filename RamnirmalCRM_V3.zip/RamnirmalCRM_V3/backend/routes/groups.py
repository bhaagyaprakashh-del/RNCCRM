from flask import Blueprint, request, jsonify
from models import db, Group
from routes.auth import token_required
from datetime import datetime

groups_bp = Blueprint('groups', __name__)

@groups_bp.route('', methods=['GET'])
@token_required
def get_groups(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    
    query = Group.query
    
    # Filter by branch if not admin
    if current_user.role != 'admin':
        query = query.filter_by(branch_id=current_user.branch_id)
    
    # Filter by status
    if status:
        query = query.filter_by(status=status)
    
    pagination = query.order_by(Group.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'groups': [group.to_dict() for group in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200

@groups_bp.route('/<int:group_id>', methods=['GET'])
@token_required
def get_group(current_user, group_id):
    group = Group.query.get_or_404(group_id)
    return jsonify(group.to_dict()), 200

@groups_bp.route('', methods=['POST'])
@token_required
def create_group(current_user):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    required_fields = ['groupNumber', 'name', 'totalMembers', 'chitValue', 'durationMonths', 'installmentAmount']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    group = Group(
        group_number=data['groupNumber'],
        name=data['name'],
        product_id=data.get('productId'),
        branch_id=data.get('branchId', current_user.branch_id),
        total_members=data['totalMembers'],
        current_members=data.get('currentMembers', 0),
        chit_value=data['chitValue'],
        duration_months=data['durationMonths'],
        installment_amount=data['installmentAmount'],
        commission_percentage=data.get('commissionPercentage'),
        start_date=datetime.fromisoformat(data['startDate']) if data.get('startDate') else None,
        status=data.get('status', 'open')
    )
    
    db.session.add(group)
    db.session.commit()
    
    return jsonify(group.to_dict()), 201

@groups_bp.route('/<int:group_id>', methods=['PUT'])
@token_required
def update_group(current_user, group_id):
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    group = Group.query.get_or_404(group_id)
    data = request.get_json()
    
    if 'name' in data:
        group.name = data['name']
    if 'currentMembers' in data:
        group.current_members = data['currentMembers']
    if 'status' in data:
        group.status = data['status']
    if 'startDate' in data:
        group.start_date = datetime.fromisoformat(data['startDate']) if data['startDate'] else None
    
    db.session.commit()
    
    return jsonify(group.to_dict()), 200

@groups_bp.route('/<int:group_id>', methods=['DELETE'])
@token_required
def delete_group(current_user, group_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    group = Group.query.get_or_404(group_id)
    db.session.delete(group)
    db.session.commit()
    
    return jsonify({'message': 'Group deleted successfully'}), 200
