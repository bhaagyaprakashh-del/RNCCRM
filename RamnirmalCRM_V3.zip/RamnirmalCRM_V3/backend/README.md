# Backend API - Deployment Instructions

## Overview
This is the Flask backend API for Chit Funds CRM. It should be deployed to the Passenger Python app location.

## Deployment Location
**Path**: `/home/w8fhnbx7quiw/pythonapps/rncrm-api`
**URL**: `https://app.chitsonline.com/api`

## Setup Instructions

### 1. Copy Backend Files
```bash
# Copy backend folder to Passenger location
cp -r backend/* /home/w8fhnbx7quiw/pythonapps/rncrm-api/
```

### 2. Install Dependencies
```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api

# Install Python packages
pip install -r requirements.txt
```

### 3. Configure Environment
```bash
# Edit .env file
nano .env

# Update these values:
# - SECRET_KEY (generate new secure random string)
# - JWT_SECRET_KEY (generate new secure random string)
```

### 4. Restart Passenger
```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
touch tmp/restart.txt
```

## Verification

### Test API Health
```bash
curl https://app.chitsonline.com/api/healthz
# Expected: {"status": "ok"}
```

### Test Database Connection
```bash
curl https://app.chitsonline.com/api/dbz
# Expected: {"database": "connected"}
```

### Test Login
```bash
curl -i -X POST https://app.chitsonline.com/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"yourpassword"}'
# Expected: 200 OK with user data and cookies
```

## File Structure
```
/home/w8fhnbx7quiw/pythonapps/rncrm-api/
├── passenger_wsgi.py          # Passenger entry point
├── requirements.txt           # Python dependencies
├── .env                       # Environment config
├── routes/                    # API route modules
│   ├── auth.py
│   ├── dashboard.py
│   ├── leads.py
│   ├── subscribers.py
│   └── ...
├── models.py                  # Database models
├── tmp/                       # Passenger control
│   └── restart.txt
└── logs/                      # Application logs
    └── app.log
```

## Important Notes

1. **Environment File**: Never commit `.env` with real secrets to version control
2. **Permissions**: Ensure proper file permissions (755 for dirs, 644 for files)
3. **Database**: Verify database credentials are correct
4. **CORS**: Ensure `CORS_ORIGINS` includes your frontend domain
5. **Logs**: Monitor `logs/app.log` for errors

## Troubleshooting

### API Returns 500 Error
- Check Passenger logs: `tail -f logs/app.log`
- Verify database connection
- Ensure all dependencies are installed

### CORS Errors
- Verify `CORS_ORIGINS` in `.env`
- Check `CORS_SUPPORTS_CREDENTIALS=True`
- Ensure frontend uses `credentials: 'include'`

### Session Not Persisting
- Verify cookies are being set
- Check `COOKIE_SECURE=True` (requires HTTPS)
- Verify `COOKIE_SAMESITE=Lax`

## Maintenance

### View Logs
```bash
tail -f /home/w8fhnbx7quiw/pythonapps/rncrm-api/logs/app.log
```

### Restart Application
```bash
touch /home/w8fhnbx7quiw/pythonapps/rncrm-api/tmp/restart.txt
```

### Update Dependencies
```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
pip install -r requirements.txt --upgrade
touch tmp/restart.txt
```

---

**Last Updated**: 2025-10-17
