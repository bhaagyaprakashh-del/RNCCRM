import sys
import os

# Add the app directory to the path
sys.path.insert(0, os.path.dirname(__file__))

# Import the Flask app
from app import create_app

application = create_app()

if __name__ == "__main__":
    application.run()
