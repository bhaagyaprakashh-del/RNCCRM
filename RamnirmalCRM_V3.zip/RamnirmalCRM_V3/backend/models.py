from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(50), nullable=False, default='agent')
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    branch_id = db.Column(db.Integer, db.ForeignKey('branches.id'))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'firstName': self.first_name,
            'lastName': self.last_name,
            'phone': self.phone,
            'branchId': self.branch_id,
            'isActive': self.is_active,
            'createdAt': self.created_at.isoformat() if self.created_at else None
        }

class Branch(db.Model):
    __tablename__ = 'branches'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    code = db.Column(db.String(50), unique=True)
    address = db.Column(db.Text)
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))
    pincode = db.Column(db.String(20))
    phone = db.Column(db.String(20))
    email = db.Column(db.String(120))
    manager_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'code': self.code,
            'address': self.address,
            'city': self.city,
            'state': self.state,
            'pincode': self.pincode,
            'phone': self.phone,
            'email': self.email,
            'managerId': self.manager_id,
            'isActive': self.is_active
        }

class Lead(db.Model):
    __tablename__ = 'leads'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120))
    phone = db.Column(db.String(20), nullable=False)
    alternate_phone = db.Column(db.String(20))
    address = db.Column(db.Text)
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))
    pincode = db.Column(db.String(20))
    source = db.Column(db.String(100))
    status = db.Column(db.String(50), default='new')
    assigned_to = db.Column(db.Integer, db.ForeignKey('users.id'))
    branch_id = db.Column(db.Integer, db.ForeignKey('branches.id'))
    interest_level = db.Column(db.String(50))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'alternatePhone': self.alternate_phone,
            'address': self.address,
            'city': self.city,
            'state': self.state,
            'pincode': self.pincode,
            'source': self.source,
            'status': self.status,
            'assignedTo': self.assigned_to,
            'branchId': self.branch_id,
            'interestLevel': self.interest_level,
            'notes': self.notes,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None
        }

class Subscriber(db.Model):
    __tablename__ = 'subscribers'
    
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.String(50), unique=True)
    name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120))
    phone = db.Column(db.String(20), nullable=False)
    alternate_phone = db.Column(db.String(20))
    address = db.Column(db.Text)
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))
    pincode = db.Column(db.String(20))
    branch_id = db.Column(db.Integer, db.ForeignKey('branches.id'))
    agent_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    kyc_status = db.Column(db.String(50), default='pending')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'customerId': self.customer_id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'alternatePhone': self.alternate_phone,
            'address': self.address,
            'city': self.city,
            'state': self.state,
            'pincode': self.pincode,
            'branchId': self.branch_id,
            'agentId': self.agent_id,
            'kycStatus': self.kyc_status,
            'isActive': self.is_active,
            'createdAt': self.created_at.isoformat() if self.created_at else None
        }

class Group(db.Model):
    __tablename__ = 'groups'
    
    id = db.Column(db.Integer, primary_key=True)
    group_number = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(200), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'))
    branch_id = db.Column(db.Integer, db.ForeignKey('branches.id'))
    total_members = db.Column(db.Integer, nullable=False)
    current_members = db.Column(db.Integer, default=0)
    chit_value = db.Column(db.Numeric(15, 2), nullable=False)
    duration_months = db.Column(db.Integer, nullable=False)
    installment_amount = db.Column(db.Numeric(15, 2), nullable=False)
    commission_percentage = db.Column(db.Numeric(5, 2))
    start_date = db.Column(db.Date)
    status = db.Column(db.String(50), default='open')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'groupNumber': self.group_number,
            'name': self.name,
            'productId': self.product_id,
            'branchId': self.branch_id,
            'totalMembers': self.total_members,
            'currentMembers': self.current_members,
            'chitValue': float(self.chit_value) if self.chit_value else 0,
            'durationMonths': self.duration_months,
            'installmentAmount': float(self.installment_amount) if self.installment_amount else 0,
            'commissionPercentage': float(self.commission_percentage) if self.commission_percentage else 0,
            'startDate': self.start_date.isoformat() if self.start_date else None,
            'status': self.status,
            'createdAt': self.created_at.isoformat() if self.created_at else None
        }

class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    code = db.Column(db.String(50), unique=True)
    description = db.Column(db.Text)
    chit_value = db.Column(db.Numeric(15, 2), nullable=False)
    duration_months = db.Column(db.Integer, nullable=False)
    max_members = db.Column(db.Integer, nullable=False)
    commission_percentage = db.Column(db.Numeric(5, 2))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'code': self.code,
            'description': self.description,
            'chitValue': float(self.chit_value) if self.chit_value else 0,
            'durationMonths': self.duration_months,
            'maxMembers': self.max_members,
            'commissionPercentage': float(self.commission_percentage) if self.commission_percentage else 0,
            'isActive': self.is_active
        }

class Collection(db.Model):
    __tablename__ = 'collections'
    
    id = db.Column(db.Integer, primary_key=True)
    subscriber_id = db.Column(db.Integer, db.ForeignKey('subscribers.id'), nullable=False)
    group_id = db.Column(db.Integer, db.ForeignKey('groups.id'), nullable=False)
    installment_number = db.Column(db.Integer, nullable=False)
    amount = db.Column(db.Numeric(15, 2), nullable=False)
    payment_date = db.Column(db.Date, nullable=False)
    payment_mode = db.Column(db.String(50))
    transaction_id = db.Column(db.String(100))
    collected_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    status = db.Column(db.String(50), default='paid')
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'subscriberId': self.subscriber_id,
            'groupId': self.group_id,
            'installmentNumber': self.installment_number,
            'amount': float(self.amount) if self.amount else 0,
            'paymentDate': self.payment_date.isoformat() if self.payment_date else None,
            'paymentMode': self.payment_mode,
            'transactionId': self.transaction_id,
            'collectedBy': self.collected_by,
            'status': self.status,
            'notes': self.notes,
            'createdAt': self.created_at.isoformat() if self.created_at else None
        }

class Auction(db.Model):
    __tablename__ = 'auctions'
    
    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey('groups.id'), nullable=False)
    auction_number = db.Column(db.Integer, nullable=False)
    auction_date = db.Column(db.Date, nullable=False)
    winner_id = db.Column(db.Integer, db.ForeignKey('subscribers.id'))
    bid_amount = db.Column(db.Numeric(15, 2))
    prize_amount = db.Column(db.Numeric(15, 2))
    dividend_amount = db.Column(db.Numeric(15, 2))
    status = db.Column(db.String(50), default='scheduled')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'groupId': self.group_id,
            'auctionNumber': self.auction_number,
            'auctionDate': self.auction_date.isoformat() if self.auction_date else None,
            'winnerId': self.winner_id,
            'bidAmount': float(self.bid_amount) if self.bid_amount else 0,
            'prizeAmount': float(self.prize_amount) if self.prize_amount else 0,
            'dividendAmount': float(self.dividend_amount) if self.dividend_amount else 0,
            'status': self.status
        }

class Commission(db.Model):
    __tablename__ = 'commissions'
    
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    type = db.Column(db.String(50), nullable=False)
    reference_id = db.Column(db.Integer)
    amount = db.Column(db.Numeric(15, 2), nullable=False)
    rate = db.Column(db.Numeric(5, 2))
    status = db.Column(db.String(50), default='pending')
    payment_date = db.Column(db.Date)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'agentId': self.agent_id,
            'type': self.type,
            'referenceId': self.reference_id,
            'amount': float(self.amount) if self.amount else 0,
            'rate': float(self.rate) if self.rate else 0,
            'status': self.status,
            'paymentDate': self.payment_date.isoformat() if self.payment_date else None,
            'notes': self.notes,
            'createdAt': self.created_at.isoformat() if self.created_at else None
        }

class Employee(db.Model):
    __tablename__ = 'employees'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True)
    employee_id = db.Column(db.String(50), unique=True)
    designation = db.Column(db.String(100))
    department = db.Column(db.String(100))
    joining_date = db.Column(db.Date)
    salary = db.Column(db.Numeric(15, 2))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'userId': self.user_id,
            'employeeId': self.employee_id,
            'designation': self.designation,
            'department': self.department,
            'joiningDate': self.joining_date.isoformat() if self.joining_date else None,
            'salary': float(self.salary) if self.salary else 0,
            'isActive': self.is_active
        }
