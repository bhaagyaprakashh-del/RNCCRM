import os
from flask import Flask
from flask_cors import CORS
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('SQLALCHEMY_DATABASE_URI')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'jwt-secret-key')
    
    # CORS configuration
    CORS(app, supports_credentials=True, origins=['https://app.chitsonline.com', 'http://localhost:3000'])
    
    # Initialize database
    from models import db
    db.init_app(app)
    
    # Register blueprints
    from routes.auth import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.leads import leads_bp
    from routes.subscribers import subscribers_bp
    from routes.groups import groups_bp
    from routes.agents import agents_bp
    from routes.collections import collections_bp
    from routes.auctions import auctions_bp
    from routes.commissions import commissions_bp
    from routes.employees import employees_bp
    from routes.products import products_bp
    from routes.branches import branches_bp
    from routes.users import users_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
    app.register_blueprint(leads_bp, url_prefix='/api/leads')
    app.register_blueprint(subscribers_bp, url_prefix='/api/subscribers')
    app.register_blueprint(groups_bp, url_prefix='/api/groups')
    app.register_blueprint(agents_bp, url_prefix='/api/agents')
    app.register_blueprint(collections_bp, url_prefix='/api/collections')
    app.register_blueprint(auctions_bp, url_prefix='/api/auctions')
    app.register_blueprint(commissions_bp, url_prefix='/api/commissions')
    app.register_blueprint(employees_bp, url_prefix='/api/employees')
    app.register_blueprint(products_bp, url_prefix='/api/products')
    app.register_blueprint(branches_bp, url_prefix='/api/branches')
    app.register_blueprint(users_bp, url_prefix='/api/users')
    
    # Health check endpoints
    @app.route('/api/healthz')
    def health():
        return {'status': 'ok', 'message': 'API is running'}, 200
    
    @app.route('/api/dbz')
    def db_check():
        try:
            from models import db
            db.session.execute('SELECT 1')
            return {'status': 'ok', 'message': 'Database connection successful'}, 200
        except Exception as e:
            return {'status': 'error', 'message': str(e)}, 500
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=False)
