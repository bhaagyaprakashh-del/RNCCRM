# API Integration Guide - Chit Funds CRM

## Overview
This guide explains how the frontend connects to the Flask API backend for end-to-end data flow: Frontend → API → MariaDB → UI.

## Architecture

```
┌─────────────────┐         ┌──────────────┐         ┌──────────────┐
│  Next.js        │         │   Flask      │         │   MariaDB    │
│  Frontend       │ ──────> │   API        │ ──────> │   Database   │
│  (React/TS)     │ <────── │   (Python)   │ <────── │              │
└─────────────────┘         └──────────────┘         └──────────────┘
      Browser                   Passenger               localhost:3306
```

## Base Configuration

### Frontend (Next.js)
```javascript
// API base URL
const API_BASE_URL = 'https://app.chitsonline.com/api';

// Fetch configuration
const fetchConfig = {
  credentials: 'include',  // Include cookies
  headers: {
    'Content-Type': 'application/json',
  },
};
```

### Backend (Flask)
```python
# Flask app configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://appapi:Bhaagyaprakashh%4055@localhost:3306/ChitsonlineCRM'
app.config['SECRET_KEY'] = '<your-secret-key>'
app.config['JWT_SECRET_KEY'] = '<your-jwt-secret>'

# CORS configuration
CORS(app, 
     origins=['https://app.chitsonline.com'],
     supports_credentials=True)
```

## Authentication Flow

### 1. Login Request
**Frontend → API**
```javascript
const login = async (username, password) => {
  const response = await fetch(`${API_BASE_URL}/auth/login`, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  
  if (response.ok) {
    const data = await response.json();
    // Cookies are automatically stored by browser
    return data.user;
  }
  throw new Error('Login failed');
};
```

**Backend Response**
```python
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(username=data['username']).first()
    
    if user and user.check_password(data['password']):
        # Create session
        session['user_id'] = user.id
        
        # Generate JWT token
        token = jwt.encode({
            'user_id': user.id,
            'exp': datetime.utcnow() + timedelta(days=1)
        }, app.config['JWT_SECRET_KEY'])
        
        # Set cookies
        response = make_response(jsonify({
            'user': user.to_dict(),
            'token': token
        }))
        response.set_cookie('authToken', token, 
                          httponly=True, 
                          secure=True, 
                          samesite='Lax',
                          max_age=86400)
        response.set_cookie('rncrm_session', session.sid,
                          httponly=True,
                          secure=True,
                          samesite='Lax')
        return response, 200
    
    return jsonify({'error': 'Invalid credentials'}), 401
```

### 2. Session Verification
**Frontend → API**
```javascript
const checkSession = async () => {
  const response = await fetch(`${API_BASE_URL}/auth/session`, {
    credentials: 'include',
  });
  
  if (response.ok) {
    return await response.json();
  }
  return null;
};
```

**Backend Response**
```python
@auth_bp.route('/session', methods=['GET'])
def get_session():
    # Check session cookie
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Or check JWT token
    token = request.cookies.get('authToken')
    if not token:
        return jsonify({'error': 'No token'}), 401
    
    try:
        payload = jwt.decode(token, app.config['JWT_SECRET_KEY'])
        user = User.query.get(payload['user_id'])
        return jsonify({'user': user.to_dict()}), 200
    except:
        return jsonify({'error': 'Invalid token'}), 401
```

### 3. Logout
**Frontend → API**
```javascript
const logout = async () => {
  await fetch(`${API_BASE_URL}/auth/logout`, {
    method: 'POST',
    credentials: 'include',
  });
  // Clear local state
  localStorage.clear();
  window.location.href = '/login';
};
```

## CRUD Operations Examples

### Leads Module

#### List Leads
```javascript
// Frontend
const fetchLeads = async () => {
  const response = await fetch(`${API_BASE_URL}/leads`, {
    credentials: 'include',
  });
  return await response.json();
};
```

```python
# Backend
@leads_bp.route('/', methods=['GET'])
@login_required
def get_leads():
    leads = Lead.query.filter_by(
        branch_id=current_user.branch_id
    ).all()
    return jsonify([lead.to_dict() for lead in leads])
```

#### Create Lead
```javascript
// Frontend
const createLead = async (leadData) => {
  const response = await fetch(`${API_BASE_URL}/leads`, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(leadData),
  });
  return await response.json();
};
```

```python
# Backend
@leads_bp.route('/', methods=['POST'])
@login_required
def create_lead():
    data = request.json
    lead = Lead(
        name=data['name'],
        phone=data['phone'],
        email=data.get('email'),
        source=data.get('source'),
        status='New',
        assigned_to=current_user.id,
        branch_id=current_user.branch_id
    )
    db.session.add(lead)
    db.session.commit()
    return jsonify(lead.to_dict()), 201
```

#### Update Lead
```javascript
// Frontend
const updateLead = async (id, leadData) => {
  const response = await fetch(`${API_BASE_URL}/leads/${id}`, {
    method: 'PUT',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(leadData),
  });
  return await response.json();
};
```

```python
# Backend
@leads_bp.route('/<int:id>', methods=['PUT'])
@login_required
def update_lead(id):
    lead = Lead.query.get_or_404(id)
    data = request.json
    
    lead.name = data.get('name', lead.name)
    lead.phone = data.get('phone', lead.phone)
    lead.status = data.get('status', lead.status)
    
    db.session.commit()
    return jsonify(lead.to_dict())
```

#### Delete Lead
```javascript
// Frontend
const deleteLead = async (id) => {
  await fetch(`${API_BASE_URL}/leads/${id}`, {
    method: 'DELETE',
    credentials: 'include',
  });
};
```

```python
# Backend
@leads_bp.route('/<int:id>', methods=['DELETE'])
@login_required
def delete_lead(id):
    lead = Lead.query.get_or_404(id)
    db.session.delete(lead)
    db.session.commit()
    return '', 204
```

### Dashboard Statistics
```javascript
// Frontend
const fetchDashboardStats = async () => {
  const response = await fetch(`${API_BASE_URL}/dashboard/stats`, {
    credentials: 'include',
  });
  return await response.json();
};
```

```python
# Backend
@dashboard_bp.route('/stats', methods=['GET'])
@login_required
def get_stats():
    branch_id = current_user.branch_id
    
    stats = {
        'total_leads': Lead.query.filter_by(branch_id=branch_id).count(),
        'total_subscribers': Subscriber.query.filter_by(branch_id=branch_id).count(),
        'active_groups': Group.query.filter_by(branch_id=branch_id, status='Active').count(),
        'pending_collections': Collection.query.filter_by(
            branch_id=branch_id, 
            status='Pending'
        ).count(),
        'total_commissions': db.session.query(func.sum(Commission.amount))\
            .filter_by(branch_id=branch_id).scalar() or 0
    }
    
    return jsonify(stats)
```

## Error Handling

### Frontend Pattern
```javascript
const apiCall = async (url, options = {}) => {
  try {
    const response = await fetch(url, {
      ...options,
      credentials: 'include',
    });
    
    if (response.status === 401) {
      // Redirect to login
      window.location.href = '/login';
      return null;
    }
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Request failed');
    }
    
    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};
```

### Backend Pattern
```python
from functools import wraps
from flask import jsonify

def handle_errors(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except ValueError as e:
            return jsonify({'error': str(e)}), 400
        except PermissionError as e:
            return jsonify({'error': 'Permission denied'}), 403
        except Exception as e:
            app.logger.error(f'Error: {str(e)}')
            return jsonify({'error': 'Internal server error'}), 500
    return decorated_function

@app.route('/some-route')
@login_required
@handle_errors
def some_route():
    # Your code here
    pass
```

## All Module Endpoints

### Authentication
- `POST /api/auth/login` - Login
- `GET /api/auth/session` - Get session
- `POST /api/auth/logout` - Logout

### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics

### Leads
- `GET /api/leads` - List all leads
- `POST /api/leads` - Create lead
- `GET /api/leads/:id` - Get lead details
- `PUT /api/leads/:id` - Update lead
- `DELETE /api/leads/:id` - Delete lead

### Subscribers
- `GET /api/subscribers` - List all subscribers
- `POST /api/subscribers` - Create subscriber
- `GET /api/subscribers/:id` - Get subscriber details
- `PUT /api/subscribers/:id` - Update subscriber
- `DELETE /api/subscribers/:id` - Delete subscriber

### Groups
- `GET /api/groups` - List all groups
- `POST /api/groups` - Create group
- `GET /api/groups/:id` - Get group details
- `PUT /api/groups/:id` - Update group
- `DELETE /api/groups/:id` - Delete group

### Agents
- `GET /api/agents` - List all agents
- `POST /api/agents` - Create agent
- `GET /api/agents/:id` - Get agent details
- `PUT /api/agents/:id` - Update agent
- `DELETE /api/agents/:id` - Delete agent

### Collections
- `GET /api/collections` - List collections
- `POST /api/collections` - Record collection
- `GET /api/collections/:id` - Get collection details
- `PUT /api/collections/:id` - Update collection
- `DELETE /api/collections/:id` - Delete collection

### Auctions
- `GET /api/auctions` - List auctions
- `POST /api/auctions` - Create auction
- `GET /api/auctions/:id` - Get auction details
- `PUT /api/auctions/:id` - Update auction
- `DELETE /api/auctions/:id` - Delete auction

### Commissions
- `GET /api/commissions` - List commissions
- `POST /api/commissions` - Calculate commission
- `GET /api/commissions/:id` - Get commission details

### Employees
- `GET /api/employees` - List employees
- `POST /api/employees` - Create employee
- `GET /api/employees/:id` - Get employee details
- `PUT /api/employees/:id` - Update employee
- `DELETE /api/employees/:id` - Delete employee

### Products
- `GET /api/products` - List products
- `POST /api/products` - Create product
- `GET /api/products/:id` - Get product details
- `PUT /api/products/:id` - Update product
- `DELETE /api/products/:id` - Delete product

### Settings
- `GET /api/settings` - Get all settings
- `PUT /api/settings` - Update settings
- `GET /api/settings/company` - Get company settings
- `PUT /api/settings/company` - Update company settings

### Branches
- `GET /api/branches` - List branches
- `POST /api/branches` - Create branch
- `GET /api/branches/:id` - Get branch details
- `PUT /api/branches/:id` - Update branch
- `DELETE /api/branches/:id` - Delete branch

### Users
- `GET /api/users` - List users
- `POST /api/users` - Create user
- `GET /api/users/:id` - Get user details
- `PUT /api/users/:id` - Update user
- `DELETE /api/users/:id` - Delete user

## Testing API Integration

### Using curl
```bash
# Test health
curl https://app.chitsonline.com/api/healthz

# Test database
curl https://app.chitsonline.com/api/dbz

# Test login
curl -i -X POST https://app.chitsonline.com/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"yourpassword"}' \
  -c cookies.txt

# Test authenticated request
curl -b cookies.txt https://app.chitsonline.com/api/dashboard/stats
```

### Using Browser Console
```javascript
// Test login
const testLogin = async () => {
  const res = await fetch('https://app.chitsonline.com/api/auth/login', {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'yourpassword' })
  });
  console.log(await res.json());
};

// Test session
const testSession = async () => {
  const res = await fetch('https://app.chitsonline.com/api/auth/session', {
    credentials: 'include'
  });
  console.log(await res.json());
};
```

## Troubleshooting

### Issue: CORS errors
**Solution**: Verify Flask CORS configuration includes credentials and correct origin

### Issue: 401 on authenticated requests
**Solution**: Check cookies are being sent, verify token not expired

### Issue: 500 errors
**Solution**: Check backend logs, verify database connection, check SQL queries

### Issue: Login works but session lost on navigation
**Solution**: Verify cookie domain/path settings, check SameSite attribute

---

**Last Updated**: 2025-10-17
