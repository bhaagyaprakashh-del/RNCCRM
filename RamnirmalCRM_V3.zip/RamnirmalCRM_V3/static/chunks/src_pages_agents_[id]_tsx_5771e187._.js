(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_agents_[id]_tsx_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_agents_[id]_tsx_5771e187._.js",
  "chunks": [
    "static/chunks/[root of the server]__49a8a82e._.js",
    "static/chunks/node_modules_next_4185f83a._.js",
    "static/chunks/node_modules_react_1cad9b0b._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
    "static/chunks/node_modules_react-dom_f14d0471._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_02ef09cd._.js",
    "static/chunks/node_modules_72bdc867._.js"
  ],
  "source": "entry"
});
