(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_leads_index_tsx_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_leads_index_tsx_5771e187._.js",
  "chunks": [
    "static/chunks/[root of the server]__05e4c853._.js",
    "static/chunks/node_modules_next_76820f37._.js",
    "static/chunks/node_modules_react_1cad9b0b._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
    "static/chunks/node_modules_react-dom_f14d0471._.js",
    "static/chunks/node_modules_3d1ec203._.js"
  ],
  "source": "entry"
});
