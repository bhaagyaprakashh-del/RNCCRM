__turbopack_load_page_chunks__("/groups/overview", [
  "static/chunks/[root of the server]__2b44d5f4._.js",
  "static/chunks/node_modules_next_03d511eb._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_45822e82._.js",
  "static/chunks/src_pages_groups_overview_tsx_5771e187._.js",
  "static/chunks/src_pages_groups_overview_tsx_241e6b22._.js"
])
