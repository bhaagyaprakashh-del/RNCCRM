__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_fba7ee81._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_5cb8b71e._.js",
  "static/chunks/[root of the server]__34ee1875._.js",
  "static/chunks/src_styles_globals_4738091e.css",
  "static/chunks/src_pages__app_5771e187._.js",
  "static/chunks/src_pages__app_71e1eb56._.js"
])
