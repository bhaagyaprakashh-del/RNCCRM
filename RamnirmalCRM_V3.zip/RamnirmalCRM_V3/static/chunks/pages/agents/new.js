__turbopack_load_page_chunks__("/agents/new", [
  "static/chunks/[root of the server]__a17bf283._.js",
  "static/chunks/node_modules_next_4185f83a._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_02ef09cd._.js",
  "static/chunks/node_modules_5c10c94c._.js",
  "static/chunks/src_pages_agents_new_tsx_5771e187._.js",
  "static/chunks/src_pages_agents_new_tsx_8a2cd558._.js"
])
