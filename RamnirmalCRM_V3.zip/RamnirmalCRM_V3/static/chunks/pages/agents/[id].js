__turbopack_load_page_chunks__("/agents/[id]", [
  "static/chunks/[root of the server]__49a8a82e._.js",
  "static/chunks/node_modules_next_4185f83a._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_02ef09cd._.js",
  "static/chunks/node_modules_72bdc867._.js",
  "static/chunks/src_pages_agents_[id]_tsx_5771e187._.js",
  "static/chunks/src_pages_agents_[id]_tsx_e3d4364a._.js"
])
