__turbopack_load_page_chunks__("/agents/targets", [
  "static/chunks/[root of the server]__0367d15a._.js",
  "static/chunks/node_modules_next_03d511eb._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_a4ad20e0._.js",
  "static/chunks/src_pages_agents_targets_tsx_5771e187._.js",
  "static/chunks/src_pages_agents_targets_tsx_53454395._.js"
])
