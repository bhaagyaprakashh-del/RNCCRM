__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_fba7ee81._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_69e050bc._.js",
  "static/chunks/[root of the server]__9da252ce._.js",
  "static/chunks/src_pages_index_5771e187._.js",
  "static/chunks/src_pages_index_52956662._.js"
])
