__turbopack_load_page_chunks__("/dashboard", [
  "static/chunks/[root of the server]__128bd118._.js",
  "static/chunks/node_modules_next_4185f83a._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_4e7b50e4._.js",
  "static/chunks/src_pages_dashboard_5771e187._.js",
  "static/chunks/src_pages_dashboard_54147c12._.js"
])
