__turbopack_load_page_chunks__("/communications/chat", [
  "static/chunks/[root of the server]__130938cf._.js",
  "static/chunks/node_modules_next_03d511eb._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_60b91ee3._.js",
  "static/chunks/src_pages_communications_chat_tsx_5771e187._.js",
  "static/chunks/src_pages_communications_chat_tsx_7fae6a7d._.js"
])
