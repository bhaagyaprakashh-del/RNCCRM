(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_campaigns_templates_tsx_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_campaigns_templates_tsx_5771e187._.js",
  "chunks": [
    "static/chunks/[root of the server]__3f7e3c7c._.js",
    "static/chunks/node_modules_next_03d511eb._.js",
    "static/chunks/node_modules_react_1cad9b0b._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
    "static/chunks/node_modules_react-dom_f14d0471._.js",
    "static/chunks/node_modules_13ced8d4._.js"
  ],
  "source": "entry"
});
