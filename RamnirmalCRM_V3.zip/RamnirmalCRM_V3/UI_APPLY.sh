#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# Chit Funds CRM - UI Deployment Script
# Safely deploys frontend assets to production
# ═══════════════════════════════════════════════════════════════

set -e  # Exit on error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
DEPLOY_DIR="/home/w8fhnbx7quiw/public_html/app.chitsonline.com"
BACKUP_DIR="/home/w8fhnbx7quiw/backups/app-backups"
SOURCE_DIR="$(dirname "$0")"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Chit Funds CRM - UI Deployment${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo ""

# Check if source directory exists
if [ ! -d "$SOURCE_DIR" ]; then
    echo -e "${RED}✗ Source directory not found: $SOURCE_DIR${NC}"
    exit 1
fi

# Create backup directory if it doesn't exist
if [ ! -d "$BACKUP_DIR" ]; then
    echo -e "${YELLOW}Creating backup directory...${NC}"
    mkdir -p "$BACKUP_DIR"
fi

# Backup existing deployment
if [ -d "$DEPLOY_DIR" ]; then
    echo -e "${YELLOW}Creating backup of current deployment...${NC}"
    BACKUP_FILE="$BACKUP_DIR/app-backup-$TIMESTAMP.tar.gz"
    tar -czf "$BACKUP_FILE" -C "$DEPLOY_DIR" . 2>/dev/null || true
    echo -e "${GREEN}✓ Backup created: $BACKUP_FILE${NC}"
fi

# Copy files to deployment directory
echo -e "${YELLOW}Deploying UI files...${NC}"

# Create deployment directory if it doesn't exist
mkdir -p "$DEPLOY_DIR"

# Copy HTML files
echo "  → Copying HTML files..."
cp "$SOURCE_DIR/index.html" "$DEPLOY_DIR/" 2>/dev/null || true
cp "$SOURCE_DIR/login.html" "$DEPLOY_DIR/" 2>/dev/null || true

# Copy .htaccess
echo "  → Copying .htaccess..."
cp "$SOURCE_DIR/.htaccess" "$DEPLOY_DIR/" 2>/dev/null || true

# Copy _next directory
if [ -d "$SOURCE_DIR/_next" ]; then
    echo "  → Copying _next static assets..."
    mkdir -p "$DEPLOY_DIR/_next"
    cp -r "$SOURCE_DIR/_next/"* "$DEPLOY_DIR/_next/" 2>/dev/null || true
fi

# Copy assets directory
if [ -d "$SOURCE_DIR/assets" ]; then
    echo "  → Copying assets..."
    mkdir -p "$DEPLOY_DIR/assets"
    cp -r "$SOURCE_DIR/assets/"* "$DEPLOY_DIR/assets/" 2>/dev/null || true
fi

# Copy favicon
if [ -f "$SOURCE_DIR/favicon.ico" ]; then
    echo "  → Copying favicon..."
    cp "$SOURCE_DIR/favicon.ico" "$DEPLOY_DIR/" 2>/dev/null || true
fi

# Set correct permissions
echo -e "${YELLOW}Setting file permissions...${NC}"
cd "$DEPLOY_DIR"
find . -type d -exec chmod 755 {} \; 2>/dev/null || true
find . -type f -exec chmod 644 {} \; 2>/dev/null || true

# Restart Passenger application
echo -e "${YELLOW}Restarting application...${NC}"
if [ -f "$DEPLOY_DIR/tmp/restart.txt" ]; then
    touch "$DEPLOY_DIR/tmp/restart.txt"
else
    mkdir -p "$DEPLOY_DIR/tmp"
    touch "$DEPLOY_DIR/tmp/restart.txt"
fi

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✓ Deployment completed successfully!${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo "  1. Purge Cloudflare cache for:"
echo "     - https://app.chitsonline.com/_next/*"
echo "     - https://app.chitsonline.com/assets/*"
echo "     - https://app.chitsonline.com/*.html"
echo ""
echo "  2. Test the deployment:"
echo "     - Open: https://app.chitsonline.com/"
echo "     - Login: https://app.chitsonline.com/login"
echo "     - Check browser console for errors"
echo ""
echo "  3. Rollback if needed:"
echo "     - Backup location: $BACKUP_FILE"
echo "     - Run: tar -xzf $BACKUP_FILE -C $DEPLOY_DIR"
echo ""
echo -e "${BLUE}Deployment timestamp: $TIMESTAMP${NC}"
echo ""
