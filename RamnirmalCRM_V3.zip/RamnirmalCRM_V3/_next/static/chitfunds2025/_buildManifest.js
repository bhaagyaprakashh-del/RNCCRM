self.__BUILD_MANIFEST = {
  "polyfillFiles": [
    "static/chunks/polyfills-42372ed130431b0a.js"
  ],
  "devFiles": [],
  "ampDevFiles": [],
  "lowPriorityFiles": [
    "static/chitfunds2025/_buildManifest.js",
    "static/chitfunds2025/_ssgManifest.js"
  ],
  "rootMainFiles": [],
  "pages": {
    "/": [
      "static/chunks/webpack-a2ac7dcd135e8ca1.js",
      "static/chunks/framework-388cbef229cd2b74.js",
      "static/chunks/main-0a5eae1510021075.js",
      "static/css/app-chitfunds.css"
    ],
    "/_app": [
      "static/chunks/webpack-a2ac7dcd135e8ca1.js",
      "static/chunks/framework-388cbef229cd2b74.js",
      "static/chunks/main-0a5eae1510021075.js",
      "static/css/app-chitfunds.css"
    ],
    "/_error": [
      "static/chunks/pages/_error-8fefcd2acbf46e83.js"
    ]
  },
  "ampFirstPages": []
};
