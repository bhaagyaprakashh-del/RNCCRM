# 🎯 Deployment Checklist

Use this checklist to ensure a smooth deployment of your Chit Funds CRM to production.

## Pre-Deployment Checklist

### 1. Environment Setup
- [ ] Database credentials confirmed (DB_USER, DB_PASSWORD, DB_NAME)
- [ ] Database is accessible from application server
- [ ] Database schema is up to date (run migrations if needed)
- [ ] Python environment is ready (Python 3.8+)
- [ ] Flask dependencies can be installed (`pip install -r backend/requirements.txt`)

### 2. Configuration Files
- [ ] Copy `backend/.env.example` to `backend/.env`
- [ ] Update all placeholders in `.env` with real values
- [ ] Set strong `SECRET_KEY` and `JWT_SECRET_KEY`
- [ ] Verify `SQLALCHEMY_DATABASE_URI` (@ encoded as %40)
- [ ] Confirm `FRONTEND_URL` matches your domain
- [ ] Check `CORS_ORIGINS` includes your domain

### 3. File Structure Verification
- [ ] `/deploy` folder contains all required files
- [ ] `index.html` and `login.html` are present
- [ ] `.htaccess` file is present with correct rules
- [ ] `/_next/static/css/app-chitfunds.css` exists
- [ ] `/assets/css/theme_glass.css` exists
- [ ] `/assets/js/app-shell.js` exists
- [ ] `backend/` folder contains Flask application files

### 4. Server Access
- [ ] SSH/FTP access to cPanel server confirmed
- [ ] Correct path to `public_html/app.chitsonline.com/` verified
- [ ] Python app directory path confirmed (`pythonapps/rncrm-api/`)
- [ ] Passenger is configured and running
- [ ] You can create/edit files in both directories

## Deployment Steps

### Phase 1: Backend API Setup

#### Step 1: Upload Backend Files
- [ ] Upload `/deploy/backend/` contents to `/home/w8fhnbx7quiw/pythonapps/rncrm-api/`
- [ ] Create `.env` file from `.env.example`
- [ ] Update `.env` with production values

#### Step 2: Install Dependencies
```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api/
pip install -r requirements.txt
```
- [ ] Dependencies installed successfully
- [ ] No error messages during installation

#### Step 3: Test Database Connection
```bash
python -c "from app import db; print('DB Connected!' if db else 'Failed')"
```
- [ ] Database connection successful

#### Step 4: Configure Passenger
- [ ] Passenger configuration file updated
- [ ] Python version specified (3.8+)
- [ ] Application entry point set to `app.py`
- [ ] Restart Passenger: `touch tmp/restart.txt`

### Phase 2: Frontend Deployment

#### Step 5: Upload Frontend Files
Choose one method:

**Method A: Using UI_APPLY.sh Script**
```bash
cd /deploy
chmod +x UI_APPLY.sh
./UI_APPLY.sh
```
- [ ] Script executed without errors
- [ ] Backup created automatically

**Method B: Manual Upload**
- [ ] Upload all files from `/deploy` to `/home/w8fhnbx7quiw/public_html/app.chitsonline.com/`
- [ ] Preserve directory structure
- [ ] `.htaccess` uploaded to root

#### Step 6: Set File Permissions
```bash
cd /home/w8fhnbx7quiw/public_html/app.chitsonline.com/
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;
```
- [ ] Permissions set correctly

### Phase 3: Cloudflare Configuration

#### Step 7: Purge Cloudflare Cache
1. Login to Cloudflare Dashboard
2. Select domain: `chitsonline.com`
3. Go to **Caching** → **Configuration**
4. Choose **Purge Everything** or **Custom Purge**

**Paths to purge:**
- [ ] `https://app.chitsonline.com/_next/static/*`
- [ ] `https://app.chitsonline.com/assets/*`
- [ ] `https://app.chitsonline.com/index.html`
- [ ] `https://app.chitsonline.com/login.html`

#### Step 8: Verify Cloudflare Settings
- [ ] SSL/TLS mode: Full (Strict) or Full
- [ ] Always Use HTTPS: Enabled
- [ ] Auto Minify: Enabled for CSS, JS
- [ ] Brotli compression: Enabled

## Post-Deployment Validation

### Phase 4: Health Checks

#### Test 1: Static Assets
```bash
curl -I https://app.chitsonline.com/_next/static/css/app-chitfunds.css
curl -I https://app.chitsonline.com/assets/css/theme_glass.css
curl -I https://app.chitsonline.com/assets/js/app-shell.js
```
- [ ] All return `200 OK`
- [ ] CSS returns `Content-Type: text/css`
- [ ] JS returns `Content-Type: application/javascript`

#### Test 2: HTML Pages
```bash
curl -I https://app.chitsonline.com/
curl -I https://app.chitsonline.com/login
```
- [ ] Both return `200 OK`
- [ ] Return `Content-Type: text/html`

#### Test 3: API Health Endpoints
```bash
curl -i https://app.chitsonline.com/api/healthz
curl -i https://app.chitsonline.com/api/dbz
curl -i https://app.chitsonline.com/health
curl -i https://app.chitsonline.com/session
```
- [ ] `/api/healthz` returns `200 {"status": "ok"}`
- [ ] `/api/dbz` returns `200 {"database": "connected"}`
- [ ] `/health` redirects correctly (200)
- [ ] `/session` returns `401` when not logged in

#### Test 4: Login Flow
1. Open browser to `https://app.chitsonline.com/login`
2. Enter test credentials
3. Submit login form

- [ ] No JavaScript console errors
- [ ] Login request goes to `/api/auth/login`
- [ ] Response sets cookies: `rncrm_session`, `authToken`
- [ ] Redirects to `/dashboard` on success
- [ ] Dashboard loads without errors

#### Test 5: Session Persistence
1. Refresh the dashboard page
2. Check if still logged in

- [ ] Session persists across refreshes
- [ ] No redirect back to login
- [ ] User data loads correctly

### Phase 5: Browser Testing

#### Desktop Testing
- [ ] Chrome (latest): All features work
- [ ] Firefox (latest): All features work
- [ ] Safari (latest): All features work
- [ ] Edge (latest): All features work

#### Mobile Testing
- [ ] iOS Safari: Responsive, drawer works
- [ ] Android Chrome: Responsive, drawer works
- [ ] Tap targets are 44px+ (touch-friendly)

#### Visual Verification
- [ ] Glassy transparent theme appears correctly
- [ ] Thin gold borders visible
- [ ] Sidebar toggle works (desktop)
- [ ] Mobile drawer opens/closes with backdrop
- [ ] Dashboard tabs switch smoothly
- [ ] KPI cards display with colored icons
- [ ] Tables are scrollable on mobile
- [ ] No layout shift on page load

### Phase 6: Performance & Accessibility

#### Lighthouse Audit
Run Lighthouse in Chrome DevTools:
- [ ] Performance: ≥ 75
- [ ] Accessibility: ≥ 90
- [ ] Best Practices: ≥ 90
- [ ] SEO: ≥ 80

#### Network Analysis
- [ ] CSS/JS files cached (check Cache-Control headers)
- [ ] Gzip/Brotli compression active
- [ ] No 404 errors in Network tab
- [ ] API calls use `credentials: include`

## Rollback Plan

### If Something Goes Wrong

#### Quick Rollback (Frontend)
```bash
cd /home/w8fhnbx7quiw/backups/app-backups
tar -xzf app-backup-YYYYMMDD_HHMMSS.tar.gz -C /home/w8fhnbx7quiw/public_html/app.chitsonline.com/
touch /home/w8fhnbx7quiw/public_html/app.chitsonline.com/tmp/restart.txt
```
- [ ] Backup restored
- [ ] Application restarted

#### Backend Rollback
1. Restore previous backend code
2. Restore `.env` if changed
3. Restart Passenger

## Sign-Off

### Deployment Completed By
- **Name:** ________________
- **Date:** ________________
- **Time:** ________________

### Verification Completed By
- **Name:** ________________
- **Date:** ________________
- **Time:** ________________

### Deployment Status
- [ ] ✅ **SUCCESS** - All checks passed
- [ ] ⚠️ **PARTIAL** - Some issues, documented below
- [ ] ❌ **FAILED** - Rolled back

### Notes / Issues Encountered
```
[Document any issues, warnings, or observations here]




```

### Post-Deployment Tasks
- [ ] Notify team of successful deployment
- [ ] Update internal documentation
- [ ] Monitor error logs for 24 hours
- [ ] Schedule follow-up review

---

**Deployment Package Version:** 1.0.0  
**Build ID:** chitfunds2025  
**Last Updated:** 2025-10-17
