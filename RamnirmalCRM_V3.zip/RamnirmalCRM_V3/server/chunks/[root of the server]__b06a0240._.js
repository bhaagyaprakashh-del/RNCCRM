module.exports = {

"[externals]/next/dist/compiled/next-server/pages-api.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/bcryptjs [external] (bcryptjs, esm_import)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
const mod = await __turbopack_context__.y("bcryptjs");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/jose [external] (jose, esm_import)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
const mod = await __turbopack_context__.y("jose");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/@prisma/client [external] (@prisma/client, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("@prisma/client", () => require("@prisma/client"));

module.exports = mod;
}}),
"[project]/src/lib/prisma.ts [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "prisma": (()=>prisma)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
;
const globalForPrisma = globalThis;
const prisma = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["PrismaClient"]({
    log: ("TURBOPACK compile-time truthy", 1) ? [
        "query",
        "error",
        "warn"
    ] : ("TURBOPACK unreachable", undefined)
});
if ("TURBOPACK compile-time truthy", 1) {
    globalForPrisma.prisma = prisma;
}
}}),
"[project]/src/lib/auth.ts [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "authenticateUser": (()=>authenticateUser),
    "clearSession": (()=>clearSession),
    "createSession": (()=>createSession),
    "getSession": (()=>getSession),
    "getSessionFromCookie": (()=>getSessionFromCookie),
    "hashPassword": (()=>hashPassword),
    "setSession": (()=>setSession),
    "verifyPassword": (()=>verifyPassword),
    "withAuth": (()=>withAuth)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$bcryptjs__$5b$external$5d$__$28$bcryptjs$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/bcryptjs [external] (bcryptjs, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$jose__$5b$external$5d$__$28$jose$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/jose [external] (jose, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$prisma$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/prisma.ts [api] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$bcryptjs__$5b$external$5d$__$28$bcryptjs$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f$jose__$5b$external$5d$__$28$jose$2c$__esm_import$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f$bcryptjs__$5b$external$5d$__$28$bcryptjs$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f$jose__$5b$external$5d$__$28$jose$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
const JWT_SECRET = new TextEncoder().encode(process.env.NEXTAUTH_SECRET || "change-this-to-a-long-random-secret-key");
// Mock user data for when database is not connected
// NOTE: In production, always use database with proper bcrypt hashes
const MOCK_USERS = [
    {
        id: "1",
        email: "admin@chitscrm.com",
        name: "Admin User",
        plainPassword: "admin123",
        role: "ADMIN",
        status: "ACTIVE",
        branch_id: "1"
    },
    {
        id: "2",
        email: "manager@chitscrm.com",
        name: "Manager User",
        plainPassword: "manager123",
        role: "MANAGER",
        status: "ACTIVE",
        branch_id: "1"
    },
    {
        id: "3",
        email: "employee@chitscrm.com",
        name: "Employee User",
        plainPassword: "employee123",
        role: "EMPLOYEE",
        status: "ACTIVE",
        branch_id: "1"
    }
];
async function hashPassword(password) {
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$bcryptjs__$5b$external$5d$__$28$bcryptjs$2c$__esm_import$29$__["hash"])(password, 10);
}
async function verifyPassword(password, hashedPassword) {
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$bcryptjs__$5b$external$5d$__$28$bcryptjs$2c$__esm_import$29$__["compare"])(password, hashedPassword);
}
async function createSession(user) {
    const token = await new __TURBOPACK__imported__module__$5b$externals$5d2f$jose__$5b$external$5d$__$28$jose$2c$__esm_import$29$__["SignJWT"]({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        branch_id: user.branch_id
    }).setProtectedHeader({
        alg: "HS256"
    }).setExpirationTime("24h").sign(JWT_SECRET);
    return token;
}
async function setSession(res, user) {
    const token = await createSession(user);
    // Set cookie using Pages Router API
    const cookieValue = `session=${token}; HttpOnly; Path=/; Max-Age=${60 * 60 * 24}; SameSite=Lax${("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : ""}`;
    res.setHeader("Set-Cookie", cookieValue);
}
async function getSessionFromCookie(cookieHeader) {
    try {
        if (!cookieHeader) {
            return null;
        }
        const sessionCookie = cookieHeader.split(";").find((c)=>c.trim().startsWith("session="))?.split("=")[1];
        if (!sessionCookie) {
            return null;
        }
        const verified = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$jose__$5b$external$5d$__$28$jose$2c$__esm_import$29$__["jwtVerify"])(sessionCookie, JWT_SECRET);
        const payload = verified.payload;
        return {
            id: payload.id,
            userId: payload.id,
            email: payload.email,
            name: payload.name,
            role: payload.role,
            branch_id: payload.branch_id
        };
    } catch (error) {
        console.error("Session verification error:", error);
        return null;
    }
}
async function getSession(req) {
    try {
        const token = req.cookies.session;
        if (!token) {
            return null;
        }
        const verified = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$jose__$5b$external$5d$__$28$jose$2c$__esm_import$29$__["jwtVerify"])(token, JWT_SECRET);
        const payload = verified.payload;
        return {
            id: payload.id,
            userId: payload.id,
            email: payload.email,
            name: payload.name,
            role: payload.role,
            branch_id: payload.branch_id
        };
    } catch (error) {
        console.error("Session verification error:", error);
        return null;
    }
}
function clearSession(res) {
    res.setHeader("Set-Cookie", "session=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax");
}
async function authenticateUser(email, password) {
    try {
        // Try to connect to database first
        const user = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$prisma$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["prisma"].user.findUnique({
            where: {
                email
            },
            select: {
                id: true,
                email: true,
                name: true,
                password: true,
                role: true,
                status: true,
                branch_id: true
            }
        });
        if (!user || user.status !== "ACTIVE") {
            return null;
        }
        const isValid = await verifyPassword(password, user.password);
        if (!isValid) {
            return null;
        }
        return {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            branch_id: user.branch_id
        };
    } catch (dbError) {
        console.warn("Database connection failed, using mock data for development:", dbError);
        // Fallback to mock data if database is not connected
        const mockUser = MOCK_USERS.find((u)=>u.email === email);
        if (!mockUser || mockUser.status !== "ACTIVE") {
            return null;
        }
        // Simple password check for mock data (development only)
        if (password !== mockUser.plainPassword) {
            return null;
        }
        console.log("✅ Mock authentication successful for:", email);
        return {
            id: mockUser.id,
            email: mockUser.email,
            name: mockUser.name,
            role: mockUser.role,
            branch_id: mockUser.branch_id
        };
    }
}
function withAuth(handler) {
    return async (req, res)=>{
        try {
            // Ensure we always return JSON, never HTML
            res.setHeader("Content-Type", "application/json");
            const session = await getSession(req);
            if (!session) {
                return res.status(401).json({
                    error: {
                        code: "UNAUTHORIZED",
                        message: "Authentication required. Please log in."
                    }
                });
            }
            // Attach session to request for handler to use
            req.session = session;
            return handler(req, res);
        } catch (error) {
            console.error("Auth middleware error:", error);
            return res.status(500).json({
                error: {
                    code: "INTERNAL_SERVER_ERROR",
                    message: "Authentication error"
                }
            });
        }
    };
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/pages/api/auth/session.ts [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "default": (()=>handler)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth.ts [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$prisma$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/prisma.ts [api] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$api$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$api$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
// Mock user data for when database is not connected
const MOCK_USER_DATA = {
    "1": {
        id: "1",
        email: "admin@chitscrm.com",
        name: "Admin User",
        role: "ADMIN",
        status: "ACTIVE",
        branch: {
            id: "1",
            code: "MB001",
            name: "Main Branch"
        }
    },
    "2": {
        id: "2",
        email: "manager@chitscrm.com",
        name: "Manager User",
        role: "MANAGER",
        status: "ACTIVE",
        branch: {
            id: "1",
            code: "MB001",
            name: "Main Branch"
        }
    },
    "3": {
        id: "3",
        email: "employee@chitscrm.com",
        name: "Employee User",
        role: "EMPLOYEE",
        status: "ACTIVE",
        branch: {
            id: "1",
            code: "MB001",
            name: "Main Branch"
        }
    }
};
async function handler(req, res) {
    if (req.method !== "GET") {
        return res.status(405).json({
            success: false,
            error: "Method not allowed"
        });
    }
    try {
        // Get session first - this will return null if no valid session exists
        const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["getSession"])(req);
        // If no session, return 401 immediately without querying database
        if (!session) {
            return res.status(401).json({
                success: false,
                error: "Not authenticated"
            });
        }
        // Session exists, now try to get user details
        try {
            // Try to get user from database
            const user = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$prisma$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["prisma"].user.findUnique({
                where: {
                    id: session.id
                },
                select: {
                    id: true,
                    email: true,
                    name: true,
                    role: true,
                    status: true,
                    branch: {
                        select: {
                            id: true,
                            code: true,
                            name: true
                        }
                    }
                }
            });
            if (!user || user.status !== "ACTIVE") {
                return res.status(401).json({
                    success: false,
                    error: "User not found or inactive"
                });
            }
            return res.status(200).json({
                success: true,
                data: {
                    user
                }
            });
        } catch (dbError) {
            console.warn("Database connection failed, using mock data for session:", dbError);
            // Fallback to mock data if database is not connected
            const mockUser = MOCK_USER_DATA[session.id];
            if (!mockUser) {
                return res.status(401).json({
                    success: false,
                    error: "User not found"
                });
            }
            return res.status(200).json({
                success: true,
                data: {
                    user: mockUser
                }
            });
        }
    } catch (error) {
        console.error("Unexpected session error:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/node_modules/next/dist/esm/server/route-modules/pages-api/module.compiled.js [api] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
} else {
    if ("TURBOPACK compile-time truthy", 1) {
        module.exports = __turbopack_context__.r("[externals]/next/dist/compiled/next-server/pages-api.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api.runtime.dev.js, cjs)");
    } else {
        "TURBOPACK unreachable";
    }
} //# sourceMappingURL=module.compiled.js.map
}}),
"[project]/node_modules/next/dist/esm/server/route-kind.js [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "RouteKind": (()=>RouteKind)
});
var RouteKind = /*#__PURE__*/ function(RouteKind) {
    /**
   * `PAGES` represents all the React pages that are under `pages/`.
   */ RouteKind["PAGES"] = "PAGES";
    /**
   * `PAGES_API` represents all the API routes under `pages/api/`.
   */ RouteKind["PAGES_API"] = "PAGES_API";
    /**
   * `APP_PAGE` represents all the React pages that are under `app/` with the
   * filename of `page.{j,t}s{,x}`.
   */ RouteKind["APP_PAGE"] = "APP_PAGE";
    /**
   * `APP_ROUTE` represents all the API routes and metadata routes that are under `app/` with the
   * filename of `route.{j,t}s{,x}`.
   */ RouteKind["APP_ROUTE"] = "APP_ROUTE";
    /**
   * `IMAGE` represents all the images that are generated by `next/image`.
   */ RouteKind["IMAGE"] = "IMAGE";
    return RouteKind;
}({}); //# sourceMappingURL=route-kind.js.map
}}),
"[project]/node_modules/next/dist/esm/build/templates/helpers.js [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * Hoists a name from a module or promised module.
 *
 * @param module the module to hoist the name from
 * @param name the name to hoist
 * @returns the value on the module (or promised module)
 */ __turbopack_context__.s({
    "hoist": (()=>hoist)
});
function hoist(module, name) {
    // If the name is available in the module, return it.
    if (name in module) {
        return module[name];
    }
    // If a property called `then` exists, assume it's a promise and
    // return a promise that resolves to the name.
    if ('then' in module && typeof module.then === 'function') {
        return module.then((mod)=>hoist(mod, name));
    }
    // If we're trying to hoise the default export, and the module is a function,
    // return the module itself.
    if (typeof module === 'function' && name === 'default') {
        return module;
    }
    // Otherwise, return undefined.
    return undefined;
} //# sourceMappingURL=helpers.js.map
}}),
"[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/auth/session.ts [api] (ecmascript)\" } [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "config": (()=>config),
    "default": (()=>__TURBOPACK__default__export__),
    "routeModule": (()=>routeModule)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$route$2d$modules$2f$pages$2d$api$2f$module$2e$compiled$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/route-modules/pages-api/module.compiled.js [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$route$2d$kind$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/route-kind.js [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$build$2f$templates$2f$helpers$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/build/templates/helpers.js [api] (ecmascript)");
// Import the userland code.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$auth$2f$session$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/pages/api/auth/session.ts [api] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$auth$2f$session$2e$ts__$5b$api$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$auth$2f$session$2e$ts__$5b$api$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$build$2f$templates$2f$helpers$2e$js__$5b$api$5d$__$28$ecmascript$29$__["hoist"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$auth$2f$session$2e$ts__$5b$api$5d$__$28$ecmascript$29$__, 'default');
const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$build$2f$templates$2f$helpers$2e$js__$5b$api$5d$__$28$ecmascript$29$__["hoist"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$auth$2f$session$2e$ts__$5b$api$5d$__$28$ecmascript$29$__, 'config');
const routeModule = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$route$2d$modules$2f$pages$2d$api$2f$module$2e$compiled$2e$js__$5b$api$5d$__$28$ecmascript$29$__["PagesAPIRouteModule"]({
    definition: {
        kind: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$route$2d$kind$2e$js__$5b$api$5d$__$28$ecmascript$29$__["RouteKind"].PAGES_API,
        page: "/api/auth/session",
        pathname: "/api/auth/session",
        // The following aren't used in production.
        bundlePath: '',
        filename: ''
    },
    userland: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$auth$2f$session$2e$ts__$5b$api$5d$__$28$ecmascript$29$__
}); //# sourceMappingURL=pages-api.js.map
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__b06a0240._.js.map