#!/bin/bash

# Chit Funds CRM - Deployment Validation Script
# Run this after deploying to verify everything is working

BASE_URL="https://app.chitsonline.com"
API_URL="$BASE_URL/api"

echo "=================================="
echo "Chit Funds CRM Deployment Validation"
echo "=================================="
echo "Testing: $BASE_URL"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

PASS=0
FAIL=0

# Function to test endpoint
test_endpoint() {
    local url=$1
    local expected_code=$2
    local description=$3
    
    echo -n "Testing: $description... "
    
    response=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)
    
    if [ "$response" = "$expected_code" ]; then
        echo -e "${GREEN}✓ PASS${NC} ($response)"
        ((PASS++))
    else
        echo -e "${RED}✗ FAIL${NC} (Expected: $expected_code, Got: $response)"
        ((FAIL++))
    fi
}

# Function to test with content type
test_content_type() {
    local url=$1
    local expected_type=$2
    local description=$3
    
    echo -n "Testing: $description... "
    
    content_type=$(curl -s -I "$url" 2>/dev/null | grep -i "content-type:" | awk '{print $2}' | tr -d '\r\n')
    
    if [[ "$content_type" == *"$expected_type"* ]]; then
        echo -e "${GREEN}✓ PASS${NC} ($content_type)"
        ((PASS++))
    else
        echo -e "${RED}✗ FAIL${NC} (Expected: $expected_type, Got: $content_type)"
        ((FAIL++))
    fi
}

echo "1. Static Assets Tests"
echo "----------------------"
test_endpoint "$BASE_URL/_next/static/css/app-chitfunds.css" "200" "CSS file loads"
test_content_type "$BASE_URL/_next/static/css/app-chitfunds.css" "text/css" "CSS MIME type"
test_endpoint "$BASE_URL/_next/static/chunks/framework-388cbef229cd2b74.js" "200" "Framework JS loads"
test_content_type "$BASE_URL/_next/static/chunks/framework-388cbef229cd2b74.js" "javascript" "JS MIME type"
test_endpoint "$BASE_URL/_next/static/chitfunds2025/_buildManifest.js" "200" "Build manifest loads"
test_endpoint "$BASE_URL/_next/static/chitfunds2025/_ssgManifest.js" "200" "SSG manifest loads"
echo ""

echo "2. Frontend Pages Tests"
echo "----------------------"
test_endpoint "$BASE_URL" "200" "Homepage loads"
test_endpoint "$BASE_URL/login" "200" "Login page loads"
test_endpoint "$BASE_URL/dashboard" "200" "Dashboard loads"
echo ""

echo "3. API Health Tests"
echo "-------------------"
test_endpoint "$API_URL/healthz" "200" "Health check endpoint"
test_endpoint "$API_URL/dbz" "200" "Database check endpoint"
echo ""

echo "4. API Shortcut Tests"
echo "---------------------"
test_endpoint "$BASE_URL/health" "200" "Health shortcut (/health → /api/healthz)"
test_endpoint "$BASE_URL/session" "401" "Session shortcut when logged out"
echo ""

echo "5. Authentication Tests"
echo "-----------------------"
test_endpoint "$API_URL/auth/session" "401" "Session endpoint (unauthorized)"
echo ""

echo "6. API Route Protection Tests"
echo "-----------------------------"
test_endpoint "$API_URL/leads" "401" "Leads endpoint (requires auth)"
test_endpoint "$API_URL/subscribers" "401" "Subscribers endpoint (requires auth)"
test_endpoint "$API_URL/dashboard/stats" "401" "Dashboard stats (requires auth)"
echo ""

echo "=================================="
echo "Validation Summary"
echo "=================================="
echo -e "${GREEN}Passed:${NC} $PASS tests"
echo -e "${RED}Failed:${NC} $FAIL tests"
echo ""

if [ $FAIL -eq 0 ]; then
    echo -e "${GREEN}✓ All tests passed! Deployment successful.${NC}"
    exit 0
else
    echo -e "${RED}✗ Some tests failed. Please review the errors above.${NC}"
    exit 1
fi
