# ~/pythonapps/cleanapi/app.py
from __future__ import annotations

import os
import sys
import logging
from typing import Optional

from flask import Flask, request, jsonify, make_response
import pymysql
import bcrypt

app = Flask(__name__)

# ---- logging to Passenger log (stdout) ----
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)
app.logger.setLevel(logging.INFO)
app.logger.addHandler(handler)

# ---- DB helpers -------------------------------------------------------------
def db_connect():
    # Use your existing env/values. Adjust if your cPanel DB creds live elsewhere.
    return pymysql.connect(
        host=os.getenv("DB_HOST", "localhost"),
        user=os.getenv("DB_USER", "w8fhnbx7quiw"),
        password=os.getenv("DB_PASS", "Prakashh@55"),
        database=os.getenv("DB_NAME", "ChitsonlineCRM"),
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
    )

def pick_bcrypt_hash(row: dict) -> Optional[str]:
    """
    Try common columns that might store the bcrypt hash.
    Returns the first bcrypt-looking value it finds.
    """
    for key in ("password_hash", "password", "passwd", "pwd_hash"):
        val = row.get(key)
        if isinstance(val, str) and val.startswith("$2") and len(val) >= 50:
            return val
    return None

def bcrypt_matches(plain: str, hashed: str) -> bool:
    """
    Normalize $2y$ -> $2b$ if needed and compare.
    """
    hv = hashed.encode("utf-8")
    if hv.startswith(b"$2y$"):
        hv = b"$2b$" + hv[4:]
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hv)
    except Exception as e:
        app.logger.warning("bcrypt error: %s", e)
        return False

# ---- routes ----------------------------------------------------------------
@app.after_request
def after(resp):
    app.logger.info("%s %s -> %s", request.method, request.path, resp.status_code)
    # Allow your static site to call these endpoints with credentials if needed
    resp.headers.setdefault("Access-Control-Allow-Origin", "https://app.chitsonline.com")
    resp.headers.setdefault("Access-Control-Allow-Credentials", "true")
    resp.headers.setdefault("Access-Control-Allow-Headers", "content-type, authorization")
    resp.headers.setdefault("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
    return resp

@app.route("/api/healthz", methods=["GET"])
def healthz():
    return jsonify(ok=True)

@app.route("/api/auth/login", methods=["POST", "OPTIONS"])
def login():
    if request.method == "OPTIONS":
        return make_response(("", 204))

    data = request.get_json(silent=True) or {}
    identity = (data.get("username") or data.get("email") or "").strip()
    password = (data.get("password") or "").strip()

    if not identity or not password:
        return jsonify(ok=False, error="missing-credentials"), 400

    # Lookup by email OR username
    sql = """
        SELECT id, email, username, name, first_name, last_name,
               password_hash, password
        FROM users
        WHERE email = %s OR username = %s
        LIMIT 1
    """
    try:
        conn = db_connect()
        with conn.cursor() as cur:
            cur.execute(sql, (identity, identity))
            row = cur.fetchone()
    except Exception as e:
        app.logger.exception("DB error during login lookup: %s", e)
        return jsonify(ok=False, error="server-error"), 500
    finally:
        try:
            conn.close()
        except Exception:
            pass

    if not row:
        app.logger.info("login: no user for identity=%r", identity)
        return jsonify(ok=False, error="invalid-credentials"), 401

    hashval = pick_bcrypt_hash(row)
    if not hashval:
        app.logger.info("login: user %r has no bcrypt-looking hash field", identity)
        return jsonify(ok=False, error="invalid-credentials"), 401

    if not bcrypt_matches(password, hashval):
        app.logger.info("login: bcrypt mismatch for identity=%r", identity)
        return jsonify(ok=False, error="invalid-credentials"), 401

    # Auth OK — no JWT issuance here, just signal availability like before
    user_payload = {
        "email": row.get("email") or row.get("username"),
        "jwt_available": True,
        "name": row.get("name"),
        "username": row.get("username"),
    }
    return jsonify(ok=True, user=user_payload), 200


# Passenger entrypoint compatibility
application = app

if __name__ == "__main__":
    # Local debug
    app.run(host="0.0.0.0", port=5000, debug=True)
