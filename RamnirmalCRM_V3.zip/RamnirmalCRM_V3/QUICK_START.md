# 🚀 Quick Start Deployment Guide

## Prerequisites Checklist

Before you begin, ensure you have:

- [x] cPanel access to app.chitsonline.com
- [x] SSH/FTP access to upload files
- [x] MariaDB database `ChitsonlineCRM` created
- [x] Database user `appapi` with password `Bhaagyaprakashh@55`
- [x] Python app location ready: `/home/w8fhnbx7quiw/pythonapps/rncrm-api`
- [x] Cloudflare account access for cache purging

---

## 5-Minute Deployment

### Step 1: Upload Frontend (2 minutes)

```bash
# Upload these files to: public_html/app.chitsonline.com/
.htaccess
index.html
login.html
dashboard.html
_next/ (entire folder)
```

**Via cPanel File Manager:**
1. Navigate to `public_html/app.chitsonline.com/`
2. Upload `.htaccess`, `index.html`, `login.html`, `dashboard.html`
3. Upload `_next` folder (keep directory structure)

**Via FTP:**
```bash
# From your local deploy folder
ftp app.chitsonline.com
# Navigate to public_html/app.chitsonline.com/
# Upload all files preserving structure
```

### Step 2: Deploy Backend (2 minutes)

**Copy backend files to Python app directory:**

```bash
# Via SSH
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api

# Copy all files from deploy/backend/
cp /path/to/deploy/backend/* .

# Or via cPanel File Manager:
# Navigate to /home/w8fhnbx7quiw/pythonapps/rncrm-api
# Upload all files from deploy/backend/ folder
```

**Install Python dependencies:**

```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
source venv/bin/activate
pip install -r requirements.txt
```

**Configure environment:**

Edit `.env` file with these required values:

```env
# Database (KEEP AS-IS)
DB_HOST=localhost
DB_PORT=3306
DB_NAME=ChitsonlineCRM
DB_USER=appapi
DB_PASSWORD=Bhaagyaprakashh@55
SQLALCHEMY_DATABASE_URI=mysql+pymysql://appapi:Bhaagyaprakashh%4055@localhost:3306/ChitsonlineCRM

# Security (CHANGE THESE - generate random strings)
SECRET_KEY=change-this-to-random-secret-key
JWT_SECRET_KEY=change-this-to-random-jwt-secret

# Flask
FLASK_ENV=production
```

**Generate secure keys (recommended):**

```python
import secrets
print("SECRET_KEY:", secrets.token_hex(32))
print("JWT_SECRET_KEY:", secrets.token_hex(32))
```

### Step 3: Configure Python App in cPanel (1 minute)

1. **Login to cPanel** → Search for "Setup Python App"
2. **Click "Create Application"**
3. **Fill in these exact values:**
   - **Python Version:** 3.9 or higher
   - **Application Root:** `/home/w8fhnbx7quiw/pythonapps/rncrm-api`
   - **Application URL:** `app.chitsonline.com/api`
   - **Application Startup File:** `passenger_wsgi.py`
   - **Application Entry Point:** `application`
4. **Click "Create"**
5. **Restart the application** if it's already running

### Step 4: Create Database Tables (30 seconds)

**Run this SQL script in phpMyAdmin:**

```sql
USE ChitsonlineCRM;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'agent',
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(20),
    branch_id INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create other required tables
CREATE TABLE IF NOT EXISTS branches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    code VARCHAR(50) UNIQUE,
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(20),
    phone VARCHAR(20),
    email VARCHAR(120),
    manager_id INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Add remaining tables from schema...
-- (See DEPLOYMENT_README.md for complete schema)
```

**OR use the automated migration script:**

```python
# In Python app directory
from app import create_app
from models import db

app = create_app()
with app.app_context():
    db.create_all()
    print("✅ All tables created successfully")
```

### Step 5: Verify Deployment (30 seconds)

**Test these URLs in your browser or with curl:**

```bash
# Health check
curl https://app.chitsonline.com/api/healthz
# Expected: {"status":"ok","message":"API is running"}

# Database check
curl https://app.chitsonline.com/api/dbz
# Expected: {"status":"ok","message":"Database connection successful"}

# Frontend
curl -I https://app.chitsonline.com/
# Expected: 200 OK

# CSS loading
curl -I https://app.chitsonline.com/_next/static/css/app-chitfunds.css
# Expected: 200 OK, Content-Type: text/css
```

**If all checks pass: ✅ Deployment Successful!**

---

## First-Time Setup Tasks

### Create Admin User

```python
# SSH into Python app directory
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
source venv/bin/activate
python3

# In Python shell:
from app import create_app
from models import db, User

app = create_app()
with app.app_context():
    # Create admin user
    admin = User(
        username='admin',
        email='admin@chitsonline.com',
        role='admin',
        first_name='System',
        last_name='Administrator',
        is_active=True
    )
    admin.set_password('ChangeThisPassword123!')
    
    db.session.add(admin)
    db.session.commit()
    
    print("✅ Admin user created successfully")
    print("Username: admin")
    print("Password: ChangeThisPassword123!")
```

### Test Login

1. **Navigate to:** `https://app.chitsonline.com/login.html`
2. **Login with:**
   - Username: `admin`
   - Password: `ChangeThisPassword123!`
3. **Should redirect to:** `https://app.chitsonline.com/dashboard.html`
4. **Change password immediately** after first login

---

## Post-Deployment Checklist

### Immediate Tasks

- [ ] Purge Cloudflare cache
- [ ] Test login flow
- [ ] Verify dashboard loads
- [ ] Check all API endpoints
- [ ] Change default admin password
- [ ] Update `.env` with secure keys

### Security Tasks

- [ ] Generate and set `SECRET_KEY` in `.env`
- [ ] Generate and set `JWT_SECRET_KEY` in `.env`
- [ ] Enable HTTPS-only cookies (already configured)
- [ ] Set up database backups
- [ ] Review user permissions

### Performance Tasks

- [ ] Enable Cloudflare caching for `/_next/static/*`
- [ ] Set cache headers for static assets
- [ ] Enable Brotli compression in Cloudflare
- [ ] Monitor API response times

### Monitoring Tasks

- [ ] Set up uptime monitoring for `/api/healthz`
- [ ] Configure log rotation in cPanel
- [ ] Set up error alerts
- [ ] Review Cloudflare Analytics

---

## Common Issues & Quick Fixes

### Issue: CSS not loading

**Symptoms:** Website loads but no styling

**Fix:**
```bash
# Check file exists
ls -la public_html/app.chitsonline.com/_next/static/css/

# Verify MIME type in .htaccess
grep "AddType text/css" public_html/app.chitsonline.com/.htaccess

# Purge Cloudflare cache
```

### Issue: API returns 500 error

**Symptoms:** Login doesn't work, API calls fail

**Fix:**
```bash
# Check Passenger logs
tail -50 /home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger.log

# Verify database connection
curl https://app.chitsonline.com/api/dbz

# Check .env file
cat /home/w8fhnbx7quiw/pythonapps/rncrm-api/.env

# Restart Python app in cPanel
```

### Issue: Database connection failed

**Symptoms:** `/api/dbz` returns error

**Fix:**
```bash
# Test database connection manually
mysql -u appapi -p'Bhaagyaprakashh@55' -h localhost ChitsonlineCRM

# Verify SQLAlchemy URI has %40 instead of @
# Correct: mysql+pymysql://appapi:Bhaagyaprakashh%4055@localhost:3306/ChitsonlineCRM
```

### Issue: Module not found error

**Symptoms:** Python import errors

**Fix:**
```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
source venv/bin/activate
pip install -r requirements.txt
# Restart app in cPanel
```

### Issue: Login redirects to wrong page

**Symptoms:** After login, shows 404 or wrong page

**Fix:**
```bash
# Verify .htaccess SPA fallback is working
# Check that index.html exists
ls -la public_html/app.chitsonline.com/index.html

# Check dashboard.html exists
ls -la public_html/app.chitsonline.com/dashboard.html

# Verify API session endpoint
curl -i https://app.chitsonline.com/api/auth/session
```

---

## Rollback Procedure

If something goes wrong:

### Frontend Rollback

```bash
# Keep backup of previous version
mv public_html/app.chitsonline.com public_html/app.chitsonline.com.backup
# Restore from backup
mv public_html/app.chitsonline.com.backup public_html/app.chitsonline.com
```

### Backend Rollback

```bash
cd /home/w8fhnbx7quiw/pythonapps/rncrm-api
# Keep backup
tar -czf backup-$(date +%Y%m%d).tar.gz *
# Restore from previous backup
# Stop app in cPanel first
```

---

## Support & Debugging

### Log Locations

```bash
# Passenger/Python logs
/home/w8fhnbx7quiw/pythonapps/rncrm-api/passenger.log

# Apache error logs
# Access via cPanel → Error Logs

# Database logs
# Access via phpMyAdmin
```

### Testing Commands

```bash
# Test all endpoints
curl https://app.chitsonline.com/api/healthz
curl https://app.chitsonline.com/api/dbz
curl https://app.chitsonline.com/api/auth/session
curl -I https://app.chitsonline.com/
curl -I https://app.chitsonline.com/_next/static/css/app-chitfunds.css

# Test login
curl -X POST https://app.chitsonline.com/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"your-password"}'
```

### Debug Mode (Development Only)

```bash
# Edit .env
FLASK_ENV=development
FLASK_DEBUG=True

# Restart app
# WARNING: Never use debug mode in production!
```

---

## Next Steps

After successful deployment:

1. **Test all modules:**
   - Leads management
   - Subscribers
   - Groups
   - Collections
   - Auctions
   - Commissions

2. **Create initial data:**
   - Add branches
   - Create products
   - Add users/agents

3. **Configure integrations:**
   - Email notifications
   - SMS gateway
   - Payment gateway

4. **Set up regular backups:**
   - Database: Daily
   - Files: Weekly
   - Logs: Monthly rotation

---

## Production Checklist

### Before Going Live

- [ ] All API endpoints tested
- [ ] Login/logout works correctly
- [ ] Database tables created
- [ ] Admin user created
- [ ] Default password changed
- [ ] Environment variables secured
- [ ] HTTPS working correctly
- [ ] Cloudflare caching configured
- [ ] Error monitoring set up
- [ ] Backup system configured

### Performance Optimization

- [ ] Cloudflare caching enabled for static assets
- [ ] Brotli compression enabled
- [ ] Database indexes created
- [ ] Slow query monitoring enabled
- [ ] CDN settings optimized

### Security Hardening

- [ ] Secure random keys generated
- [ ] Database user permissions minimal
- [ ] CORS configured correctly
- [ ] Rate limiting configured
- [ ] SQL injection protection enabled
- [ ] XSS protection enabled

---

## Success! 🎉

Your Chit Funds CRM is now live at:

**🌐 Frontend:** https://app.chitsonline.com

**🔌 API:** https://app.chitsonline.com/api

**📊 Dashboard:** https://app.chitsonline.com/dashboard.html

---

**Need Help?**
- Review logs in cPanel
- Check DEPLOYMENT_README.md for detailed troubleshooting
- Verify all endpoints with curl commands above
- Test database connection manually

**Deployment Time:** ~5 minutes
**Version:** 1.0.0
**Last Updated:** 2025-10-17
