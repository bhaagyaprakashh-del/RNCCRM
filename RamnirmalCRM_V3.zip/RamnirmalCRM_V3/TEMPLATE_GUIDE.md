# 📄 Page Template Usage Guide

## Overview

`PAGE_TEMPLATE.html` is a comprehensive starting point for creating any new page in the Chit Funds CRM with the glassy transparent theme.

---

## 🚀 Quick Start

### Step 1: Copy the Template

```bash
cp deploy/PAGE_TEMPLATE.html deploy/your-new-page.html
```

### Step 2: Replace Placeholders

Find and replace these placeholders:

| Placeholder | Replace With | Example |
|------------|--------------|---------|
| `[PAGE TITLE]` | Your page title | "Collections Management" |
| `[Your Page Title]` | Main heading | "Monthly Collections Report" |

### Step 3: Update Active Sidebar Item

Find the sidebar link for your page and add the `active` class:

```html
<!-- Before -->
<a href="/collections" class="sidebar-item">
  <span class="sidebar-icon">💰</span>
  <span class="sidebar-label">Collections</span>
</a>

<!-- After -->
<a href="/collections" class="sidebar-item active">
  <span class="sidebar-icon">💰</span>
  <span class="sidebar-label">Collections</span>
</a>
```

### Step 4: Add Your Content

Replace the example sections with your actual content.

---

## 🎨 Available Components

### 1. KPI Cards

**Use for**: Dashboard metrics, summary statistics

```html
<div class="grid-3 mb-3 fade-in">
  <div class="kpi-card">
    <div class="kpi-icon blue">📊</div>
    <div class="kpi-content">
      <div class="kpi-label">Label</div>
      <div class="kpi-value">1,234</div>
      <div class="kpi-trend up">↑ 12%</div>
    </div>
  </div>
</div>
```

**Available icon colors**: `blue`, `green`, `red`, `yellow`, `violet`

**Trend classes**: `up` (green arrow), `down` (red arrow), none (neutral)

---

### 2. Glass Cards

**Use for**: Content sections, forms, charts

```html
<div class="glass-card">
  <h3 class="text-primary mb-2">Card Title</h3>
  <p class="text-secondary">Card content</p>
</div>
```

**Layout classes**:
- `grid-1`: Single column
- `grid-2`: Two columns (auto-fit, responsive)
- `grid-3`: Three columns (auto-fit, responsive)

---

### 3. Tables

**Use for**: Data lists, reports

```html
<div class="glass-card">
  <h3 class="text-primary mb-2">Table Title</h3>
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>Column 1</th>
          <th>Column 2</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Data 1</td>
          <td>Data 2</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
```

**Features**:
- Sticky header on scroll
- Sticky first column (mobile)
- Horizontal scroll for overflow
- Hover effect on rows

---

### 4. Forms

**Use for**: Data input, filters, settings

```html
<div class="glass-card">
  <h3 class="text-primary mb-2">Form Title</h3>
  <form id="myForm">
    <div class="form-group mb-3">
      <label for="field">Label</label>
      <input
        type="text"
        id="field"
        name="field"
        placeholder="Enter value..."
        style="width: 100%; height: 40px; padding: 0 1rem; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 0.75rem; color: var(--text-primary);"
      />
    </div>
    <button type="submit" style="height: 40px; padding: 0 2rem; background: var(--accent-blue); color: white; border: none; border-radius: 0.75rem; font-weight: 600; cursor: pointer;">
      Submit
    </button>
  </form>
</div>
```

---

### 5. Buttons

**Primary button** (blue):
```html
<button style="height: 40px; padding: 0 2rem; background: var(--accent-blue); color: white; border: none; border-radius: 0.75rem; font-weight: 600; cursor: pointer; transition: all 0.2s;">
  Primary Action
</button>
```

**Secondary button** (outlined):
```html
<button style="height: 40px; padding: 0 2rem; background: transparent; color: var(--text-primary); border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 0.75rem; font-weight: 600; cursor: pointer; transition: all 0.2s;">
  Secondary Action
</button>
```

---

### 6. Status Colors

**Text colors**:
- `.text-green`: Success, active, completed
- `.text-blue`: Info, pending, in progress
- `.text-yellow`: Warning, scheduled
- `.text-red`: Error, urgent, failed
- `.text-primary`: Main text (white)
- `.text-secondary`: Secondary text (dimmed white)
- `.text-muted`: Muted text (faded white)

```html
<span class="text-green">Active</span>
<span class="text-yellow">Pending</span>
<span class="text-red">Failed</span>
```

---

### 7. Animations

**Fade in** (opacity):
```html
<div class="fade-in">
  <!-- Content fades in on scroll -->
</div>
```

**Slide up** (translate Y):
```html
<div class="slide-up">
  <!-- Content slides up on scroll -->
</div>
```

---

## 🔄 Loading Data from API

### Basic Pattern

```javascript
fetch('/api/your-endpoint', {
  credentials: 'include'
})
.then(res => {
  if (!res.ok) throw new Error('API error');
  return res.json();
})
.then(data => {
  console.log('Data loaded:', data);
  // Update your page with real data
  updatePageContent(data);
})
.catch(err => {
  console.error('Error loading data:', err);
  // Show error message to user
  showErrorMessage('Failed to load data');
});
```

### Example: Populate Table

```javascript
fetch('/api/collections', {
  credentials: 'include'
})
.then(res => res.json())
.then(data => {
  const tbody = document.querySelector('table tbody');
  tbody.innerHTML = data.collections.map(item => `
    <tr>
      <td>${item.date}</td>
      <td>${item.subscriber}</td>
      <td>₹${item.amount.toLocaleString()}</td>
      <td><span class="text-green">${item.status}</span></td>
    </tr>
  `).join('');
})
.catch(err => {
  console.error('Error:', err);
});
```

### Example: Update KPI Cards

```javascript
fetch('/api/dashboard/stats', {
  credentials: 'include'
})
.then(res => res.json())
.then(data => {
  document.querySelector('.kpi-value').textContent = data.totalCollections.toLocaleString();
  document.querySelector('.kpi-trend').textContent = `↑ ${data.growthPercent}%`;
});
```

---

## 📱 Responsive Behavior

The template is **fully responsive** by default:

### Mobile (<768px)
- Sidebar becomes slide-in drawer
- KPI cards stack (1 column)
- Tables scroll horizontally
- Touch-friendly tap targets (44px+)

### Tablet (768px-1024px)
- Two-column grid for cards
- Sidebar visible, collapsible

### Desktop (>1024px)
- Three-column grid for cards
- Full sidebar with labels

---

## ✅ Pre-Deployment Checklist

Before using your new page in production:

- [ ] Replaced all `[PAGE TITLE]` placeholders
- [ ] Updated sidebar active state
- [ ] Removed example sections
- [ ] Added your actual content
- [ ] Tested on desktop, tablet, mobile
- [ ] Verified API calls work with `credentials: 'include'`
- [ ] Tested session validation (redirects to login when not authenticated)
- [ ] Checked for console errors
- [ ] Verified all links/buttons are functional
- [ ] Tested forms (if any) with valid/invalid data

---

## 🎯 Common Use Cases

### Use Case 1: Simple List Page

**Goal**: Show a list of items (e.g., subscribers, agents, products)

**Steps**:
1. Copy template
2. Add page title
3. Use glass-card with table-container
4. Fetch data from API
5. Populate table rows

**Result**: Responsive list page with glassy theme

---

### Use Case 2: Dashboard with Stats

**Goal**: Show KPIs, charts, recent activity

**Steps**:
1. Copy template
2. Add page title
3. Use grid-3 with kpi-cards
4. Add glass-cards for charts/activity
5. Fetch stats from API

**Result**: Dashboard with metrics and visualizations

---

### Use Case 3: Form Page

**Goal**: Create/edit records

**Steps**:
1. Copy template
2. Add page title
3. Use glass-card with form
4. Add input fields
5. Handle form submit with POST/PUT to API

**Result**: Form page that saves data

---

### Use Case 4: Report Page

**Goal**: Display charts, tables, filters

**Steps**:
1. Copy template
2. Add page title
3. Use grid-2 for filters + results
4. Use glass-card for charts
5. Use table-container for data
6. Fetch report data from API

**Result**: Interactive report page

---

## 🔧 Customization Tips

### Change Card Border Color

```css
<div class="glass-card" style="border-color: var(--accent-gold);">
  <!-- Gold border instead of default -->
</div>
```

### Add Custom Icon

```html
<div class="kpi-icon" style="background: rgba(139, 92, 246, 0.15);">
  🎨
</div>
```

### Custom Button Style

```html
<button style="background: var(--accent-green); ...">
  Success Button
</button>
```

---

## 📚 Related Files

- **Template**: `deploy/PAGE_TEMPLATE.html`
- **CSS Theme**: `deploy/assets/css/theme_glass.css`
- **JavaScript**: `deploy/assets/js/app-shell.js`
- **Main CSS**: `deploy/_next/static/css/app-chitfunds.css`

---

## ❓ Troubleshooting

### Issue: Sidebar not showing active state

**Solution**: Ensure the `active` class is on the correct sidebar item for your page.

### Issue: Animations not working

**Solution**: Make sure `app-shell.js` is loaded without errors. Check browser console.

### Issue: API calls failing

**Solution**: Verify `credentials: 'include'` is in all fetch calls and API endpoints are correct.

### Issue: Forms not submitting

**Solution**: Add `event.preventDefault()` in form submit handler, then manually POST data.

---

**Template Version**: 1.0.0  
**Last Updated**: 2025-10-18  
**Compatibility**: All modules, all roles

Start building your new page now! 🚀
