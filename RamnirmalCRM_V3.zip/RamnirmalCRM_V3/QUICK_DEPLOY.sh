#!/bin/bash

# Chit Funds CRM - Quick Deployment Script
# Version: 1.0.0
# This script helps verify deployment readiness

echo "=================================="
echo "Chit Funds CRM Deployment Checker"
echo "=================================="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

DOMAIN="https://app.chitsonline.com"

echo "Testing deployment at: $DOMAIN"
echo ""

# Test 1: Health Check
echo -n "1. Testing API health... "
HEALTH=$(curl -s -o /dev/null -w "%{http_code}" $DOMAIN/api/healthz)
if [ "$HEALTH" = "200" ]; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL (HTTP $HEALTH)${NC}"
fi

# Test 2: Database Check
echo -n "2. Testing database connection... "
DB=$(curl -s -o /dev/null -w "%{http_code}" $DOMAIN/api/dbz)
if [ "$DB" = "200" ]; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL (HTTP $DB)${NC}"
fi

# Test 3: Session Endpoint
echo -n "3. Testing session endpoint (should be 401)... "
SESSION=$(curl -s -o /dev/null -w "%{http_code}" $DOMAIN/api/auth/session)
if [ "$SESSION" = "401" ]; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${YELLOW}⚠ UNEXPECTED (HTTP $SESSION)${NC}"
fi

# Test 4: CSS File
echo -n "4. Testing CSS file... "
CSS=$(curl -s -o /dev/null -w "%{http_code}" $DOMAIN/_next/static/css/app-chitfunds.css)
if [ "$CSS" = "200" ]; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL (HTTP $CSS)${NC}"
fi

# Test 5: Build Manifest
echo -n "5. Testing build manifest... "
MANIFEST=$(curl -s -o /dev/null -w "%{http_code}" $DOMAIN/_next/static/chitfunds2025/_buildManifest.js)
if [ "$MANIFEST" = "200" ]; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL (HTTP $MANIFEST)${NC}"
fi

# Test 6: Index Page
echo -n "6. Testing index page... "
INDEX=$(curl -s -o /dev/null -w "%{http_code}" $DOMAIN/)
if [ "$INDEX" = "200" ]; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL (HTTP $INDEX)${NC}"
fi

# Test 7: Login Page
echo -n "7. Testing login page... "
LOGIN=$(curl -s -o /dev/null -w "%{http_code}" $DOMAIN/login.html)
if [ "$LOGIN" = "200" ]; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL (HTTP $LOGIN)${NC}"
fi

echo ""
echo "=================================="
echo "Deployment verification complete!"
echo "=================================="
echo ""
echo "Next steps:"
echo "1. Test login in browser: $DOMAIN"
echo "2. Default credentials: admin / Admin@123!"
echo "3. Change password after first login"
echo "4. Start using the application"
echo ""
